# AniFlow — Architecture & Project Specification

> **Platform:** Telegram Mini App
> **Stack:** Next.js 15 · React 19 · TypeScript · TailwindCSS · Telegram Mini Apps SDK · Framer Motion · React Query · Zustand · Lucide Icons
> **Languages:** English, Ukrainian, Russian

---

## 1. Folder Structure

```
d:/AniFlow/
│
├── public/
│   ├── icons/                  # SVG icons, app icons
│   ├── images/                 # Static images, og-images, placeholders
│   ├── videos/                 # Trailer / preview clips
│   └── fonts/                  # Local fonts (if self-hosted)
│
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── (telegram)/         # Telegram-gated layout (MainNav)
│   │   │   ├── home/           # /home — vertical TikTok feed
│   │   │   ├── explore/        # /explore — search, genres, filters
│   │   │   ├── library/        # /library — favorites, history, continue
│   │   │   ├── profile/        # /profile — user profile & settings entry
│   │   │   └── layout.tsx      # (telegram) layout — bottom nav + providers
│   │   ├── anime/
│   │   │   └── [id]/           # /anime/[id] — anime detail page
│   │   ├── player/
│   │   │   └── [id]/           # /player/[id] — vertical player
│   │   ├── premium/            # /premium — subscription page
│   │   ├── settings/           # /settings — language, theme, notifications
│   │   ├── referral/           # /referral — referral program page
│   │   ├── admin/              # /admin — admin dashboard (guarded)
│   │   │   ├── anime/          # Admin: anime CRUD
│   │   │   ├── users/          # Admin: user management
│   │   │   └── stats/          # Admin: statistics
│   │   ├── layout.tsx          # Root layout — Telegram init, providers
│   │   ├── page.tsx            # Entry — redirects to /home
│   │   ├── globals.css         # Tailwind + global styles
│   │   ├── error.tsx           # Global error boundary
│   │   ├── loading.tsx         # Global loading (skeleton)
│   │   └── not-found.tsx       # 404 page
│   │
│   ├── components/
│   │   ├── ui/                 # Reusable primitives
│   │   │   ├── Button.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Skeleton.tsx
│   │   │   ├── Modal.tsx
│   │   │   ├── Sheet.tsx
│   │   │   ├── Badge.tsx
│   │   │   ├── Avatar.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── Tabs.tsx
│   │   │   ├── ProgressBar.tsx
│   │   │   ├── PremiumBadge.tsx
│   │   │   └── GlassCard.tsx
│   │   ├── layout/
│   │   │   ├── BottomNav.tsx
│   │   │   ├── Header.tsx
│   │   │   └── SafeArea.tsx
│   │   ├── home/
│   │   │   ├── FeedItem.tsx
│   │   │   ├── FeedActionBar.tsx
│   │   │   ├── EpisodeInfo.tsx
│   │   │   ├── PremiumOverlay.tsx
│   │   │   ├── ContinueWatchingRow.tsx
│   │   │   ├── RecommendedRow.tsx
│   │   │   ├── TrendingRow.tsx
│   │   │   └── RecentlyAddedRow.tsx
│   │   ├── explore/
│   │   │   ├── SearchBar.tsx
│   │   │   ├── GenreChips.tsx
│   │   │   ├── FilterBar.tsx
│   │   │   ├── AnimeGrid.tsx
│   │   │   └── SortTabs.tsx
│   │   ├── anime/
│   │   │   ├── AnimeHero.tsx
│   │   │   ├── AnimeMeta.tsx
│   │   │   ├── SeasonList.tsx
│   │   │   ├── EpisodeList.tsx
│   │   │   ├── EpisodeCard.tsx
│   │   │   ├── RecommendationCarousel.tsx
│   │   │   └── AnimeActions.tsx
│   │   ├── player/
│   │   │   ├── VideoPlayer.tsx
│   │   │   ├── PlayerControls.tsx
│   │   │   ├── PlayerOverlay.tsx
│   │   │   ├── NextEpisodeToast.tsx
│   │   │   ├── SpeedMenu.tsx
│   │   │   └── EpisodeLockOverlay.tsx
│   │   ├── premium/
│   │   │   ├── PremiumHero.tsx
│   │   │   ├── PremiumBenefits.tsx
│   │   │   ├── SubscriptionCard.tsx
│   │   │   ├── SeasonPassCard.tsx
│   │   │   └── StarsCheckout.tsx
│   │   ├── profile/
│   │   │   ├── ProfileHeader.tsx
│   │   │   ├── ProfileStats.tsx
│   │   │   ├── ReferralCard.tsx
│   │   │   ├── SettingsList.tsx
│   │   │   └── HistoryList.tsx
│   │   ├── referral/
│   │   │   ├── ReferralHero.tsx
│   │   │   ├── ReferralProgress.tsx
│   │   │   ├── ReferralHistory.tsx
│   │   │   └── CopyLinkButton.tsx
│   │   ├── admin/
│   │   │   ├── AdminDashboard.tsx
│   │   │   ├── AnimeForm.tsx
│   │   │   ├── EpisodeForm.tsx
│   │   │   ├── UserTable.tsx
│   │   │   └── StatsGrid.tsx
│   │   └── shared/
│   │       ├── LanguageSwitcher.tsx
│   │       ├── ThemeToggle.tsx
│   │       ├── Loader.tsx
│   │       ├── EmptyState.tsx
│   │       ├── ErrorState.tsx
│   │       ├── Toast.tsx
│   │       ├── StarRating.tsx
│   │       └── ImageWithFallback.tsx
│   │
│   ├── config/
│   │   ├── constants.ts       # App constants, limits
│   │   ├── telegram.ts        # Telegram SDK config
│   │   ├── api.ts             # API base URLs
│   │   └── themes.ts          # Theme definitions
│   │
│   ├── features/              # Feature-based modules (clean arch)
│   │   ├── auth/
│   │   │   ├── useAuth.ts
│   │   │   └── auth.service.ts
│   │   ├── anime/
│   │   │   ├── useAnime.ts
│   │   │   ├── useAnimeList.ts
│   │   │   ├── useEpisodes.ts
│   │   │   └── anime.service.ts
│   │   ├── player/
│   │   │   ├── usePlayer.ts
│   │   │   └── player.service.ts
│   │   ├── library/
│   │   │   ├── useFavorites.ts
│   │   │   ├── useHistory.ts
│   │   │   └── library.service.ts
│   │   ├── premium/
│   │   │   ├── usePremium.ts
│   │   │   └── premium.service.ts
│   │   ├── referral/
│   │   │   ├── useReferral.ts
│   │   │   └── referral.service.ts
│   │   └── notifications/
│   │       ├── useNotifications.ts
│   │       └── notifications.service.ts
│   │
│   ├── hooks/
│   │   ├── useTelegram.ts
│   │   ├── useInfiniteScroll.ts
│   │   ├── useIsMobile.ts
│   │   ├── useDebounce.ts
│   │   ├── useSwipe.ts
│   │   ├── useMediaQuery.ts
│   │   └── useHaptic.ts
│   │
│   ├── lib/
│   │   ├── api-client.ts      # Fetch wrapper w/ error handling
│   │   ├── query-client.ts    # React Query client config
│   │   ├── haptics.ts         # Telegram haptic feedback
│   │   ├── storage.ts         # Local storage wrapper
│   │   ├── share.ts           # Telegram share helper
│   │   └── utils.ts           # Generic utilities
│   │
│   ├── services/
│   │   ├── telegram.service.ts
│   │   ├── auth.service.ts
│   │   ├── anime.service.ts
│   │   ├── payments.service.ts
│   │   ├── notifications.service.ts
│   │   └── admin.service.ts
│   │
│   ├── store/
│   │   ├── userStore.ts
│   │   ├── playerStore.ts
│   │   ├── uiStore.ts
│   │   └── libraryStore.ts
│   │
│   ├── types/
│   │   ├── user.ts
│   │   ├── anime.ts
│   │   ├── episode.ts
│   │   ├── premium.ts
│   │   ├── referral.ts
│   │   ├── notification.ts
│   │   ├── api.ts
│   │   └── navigation.ts
│   │
│   ├── utils/
│   │   ├── format.ts          # View counts, durations, dates
│   │   ├── validation.ts
│   │   └── constants.ts
│   │
│   └── i18n/
│       ├── locales/
│       │   ├── en.ts
│       │   ├── uk.ts
│       │   └── ru.ts
│       ├── index.ts
│       └── LanguageProvider.tsx
│
├── .env.local
├── .env.example
├── .eslintrc.json
├── .gitignore
├── next.config.mjs
├── package.json
├── postcss.config.mjs
├── tailwind.config.ts
├── tsconfig.json
├── README.md
└── ARCHITECTURE.md
```

---

## 2. Project Architecture

### 2.1 Frontend Architecture

- **Next.js 15 App Router** — file-based routing, RSC + client components.
- **Telegram Mini Apps SDK** — initialized in root layout via `@telegram-apps/sdk-react`.
- **Zustand** — client-side global state (user, player, UI, library).
- **React Query** — server-state caching, infinite queries for feed & lists, mutations for likes/favorites.
- **Framer Motion** — all UI animations (60 FPS, GPU-accelerated transforms).
- **TailwindCSS** — utility-first styling with custom neon-purple cyberpunk theme.
- **i18n** — lightweight custom provider (en/uk/ru) with `t()` function, persisted in localStorage + Telegram settings.

### 2.2 State Management

| Store | Purpose |
|-------|---------|
| `userStore` | Telegram user, auth token, premium status, language |
| `playerStore` | Current episode, playback speed, muted, fullscreen, progress |
| `uiStore` | Bottom nav visibility, theme, modals, toasts |
| `libraryStore` | Favorites (cached), history (cached), continue watching |

### 2.3 Data Flow

```
Telegram SDK → Auth Service → Backend API → React Query cache → UI components
                                     ↓
                              User actions (like/share) → Mutations → Optimistic updates
```

### 2.4 Key Design Decisions

- **Vertical feed** — virtualized list (windowing) for 60 FPS performance.
- **Video autoplay** — IntersectionObserver + `play()` on visible items, pause on hidden.
- **Premium gating** — client guard + server-side enforcement (episodes 4+ locked).
- **Telegram Stars payments** — backend webhook receives `invoice.paid` to grant premium/season pass.
- **Offline-first** — library & settings cached in localStorage; feed cached via React Query `staleTime`.
- **Skeletons** — all data-driven sections render skeleton loaders matching final layout.

---

## 3. Routing

| Route | Page | Access | Description |
|-------|------|--------|-------------|
| `/` | `app/page.tsx` | All | Redirect → `/home` |
| `/home` | `(telegram)/home/page.tsx` | All | TikTok-style vertical feed |
| `/explore` | `(telegram)/explore/page.tsx` | All | Search, genres, filters, sorts |
| `/library` | `(telegram)/library/page.tsx` | All | Favorites, history, continue watching |
| `/profile` | `(telegram)/profile/page.tsx` | All | Profile, premium status, referral, settings |
| `/anime/[id]` | `anime/[id]/page.tsx` | All | Anime details, seasons, episodes, recommendations |
| `/player/[id]` | `player/[id]/page.tsx` | All | Fullscreen vertical player |
| `/premium` | `premium/page.tsx` | All | Premium + season pass purchase |
| `/settings` | `settings/page.tsx` | All | Language, theme, notifications, about |
| `/referral` | `referral/page.tsx` | All | Referral program, progress, rewards |
| `/admin` | `admin/page.tsx` | Admin | Admin dashboard (guarded) |
| `/admin/anime` | `admin/anime/page.tsx` | Admin | Anime CRUD |
| `/admin/users` | `admin/users/page.tsx` | Admin | User management |
| `/admin/stats` | `admin/stats/page.tsx` | Admin | Statistics |

**Route guards:** `(telegram)` layout wraps all main navigation with `BottomNav`. Admin routes check `user.isAdmin` + server session.

---

## 4. Component Tree

```
Root Layout
├── TelegramProvider
├── QueryClientProvider
├── LanguageProvider
├── ThemeProvider
├── Toaster
└── (telegram) Layout
    ├── Header (contextual)
    ├── Page Content
    │   ├── Home
    │   │   ├── FeedItem[]
    │   │   │   ├── VideoPlayer
    │   │   │   ├── EpisodeInfo
    │   │   │   ├── FeedActionBar (like, favorite, share)
    │   │   │   ├── PremiumOverlay (locked episodes)
    │   │   │   └── ProgressBar
    │   │   ├── ContinueWatchingRow
    │   │   ├── RecommendedRow
    │   │   ├── TrendingRow
    │   │   └── RecentlyAddedRow
    │   ├── Explore
    │   │   ├── SearchBar
    │   │   ├── GenreChips
    │   │   ├── SortTabs (Popular/New/Top/Completed/Ongoing)
    │   │   ├── FilterBar
    │   │   └── AnimeGrid
    │   │       └── AnimeCard
    │   ├── Library
    │   │   ├── Tabs (Favorites / History / Continue)
    │   │   ├── FavoriteList
    │   │   ├── HistoryList
    │   │   └── ContinueList
    │   ├── Profile
    │   │   ├── ProfileHeader (avatar, username, premium badge)
    │   │   ├── ProfileStats (likes, favorites, referrals)
    │   │   ├── ReferralCard
    │   │   ├── SettingsList
    │   │   └── HistoryList
    │   └── Anime Detail
    │       ├── AnimeHero (cover, title, meta)
    │       ├── AnimeActions (like, favorite, share)
    │       ├── SeasonList
    │       │   └── EpisodeList
    │       │       └── EpisodeCard (locked overlay)
    │       └── RecommendationCarousel
    ├── Player
    │   ├── VideoPlayer
    │   ├── PlayerControls (play/pause, speed, mute, fullscreen)
    │   ├── PlayerOverlay (title, episode, premium popup)
    │   ├── NextEpisodeToast
    │   └── EpisodeLockOverlay / PremiumPopup
    ├── Premium
    │   ├── PremiumHero
    │   ├── PremiumBenefits
    │   ├── SubscriptionCard (Telegram Stars)
    │   └── SeasonPassCard
    ├── Settings
    │   ├── LanguageSwitcher
    │   ├── ThemeToggle
    │   ├── NotificationToggle
    │   └── About / Privacy / Terms / Support
    ├── Referral
    │   ├── ReferralHero
    │   ├── ReferralProgress
    │   ├── ReferralHistory
    │   └── CopyLinkButton
    └── Admin
        ├── AdminDashboard
        ├── AnimeForm
        ├── EpisodeForm
        ├── UserTable
        └── StatsGrid
└── BottomNav
    ├── HomeTab
    ├── ExploreTab
    ├── LibraryTab
    └── ProfileTab
```

---

## 5. Database Models

### 5.1 User

```
ts
interface User {
  id: string;                 // Telegram user ID
  username: string;
  first_name: string;
  last_name?: string;
  avatar_url?: string;
  language: 'en' | 'uk' | 'ru';
  is_premium: boolean;
  premium_expires_at?: Date;
  is_admin: boolean;
  referral_code: string;
  referred_by?: string;       // user id
  referral_count: number;
  created_at: Date;
  updated_at: Date;
}
```

### 5.2 Anime

```
ts
interface Anime {
  id: string;
  title: { en: string; uk: string; ru: string };
  description: { en: string; uk: string; ru: string };
  cover_url: string;
  banner_url: string;
  trailer_url?: string;
  studio: string;
  genres: string[];
  status: 'ongoing' | 'completed';
  rating: number;             // 0-10
  views: number;
  likes: number;
  is_premium: boolean;        // premium-exclusive anime
  created_at: Date;
}
```

### 5.3 Season

```
ts
interface Season {
  id: string;
  anime_id: string;
  number: number;
  title: { en: string; uk: string; ru: string };
  episode_count: number;
}
```

### 5.4 Episode

```
ts
interface Episode {
  id: string;
  season_id: string;
  anime_id: string;
  number: number;             // global episode number
  title: { en: string; uk: string; ru: string };
  video_url: string;
  thumbnail_url: string;
  duration: number;           // seconds
  is_free: boolean;           // first 3 free = true
  views: number;
  likes: number;
}
```

### 5.5 PremiumSubscription

```
ts
interface PremiumSubscription {
  id: string;
  user_id: string;
  plan: 'monthly' | 'yearly';
  status: 'active' | 'expired' | 'cancelled';
  started_at: Date;
  expires_at: Date;
  telegram_payment_id?: string;
}
```

### 5.6 SeasonPass

```
ts
interface SeasonPass {
  id: string;
  user_id: string;
  anime_id: string;
  status: 'active' | 'expired';
  purchased_at: Date;
  expires_at?: Date;          // null = lifetime
  telegram_payment_id?: string;
}
```

### 5.7 Favorite

```
ts
interface Favorite {
  id: string;
  user_id: string;
  anime_id: string;
  created_at: Date;
}
```

### 5.8 WatchHistory

```ts
interface WatchHistory {
  id: string;
  user_id: string;
  anime_id: string;
  episode_id: string;
  progress: number;           // 0-100 (% watched)
  last_watched_at: Date;
}
```

### 5.9 Referral

```
ts
interface Referral {
  id: string;
  referrer_id: string;
  referred_user_id: string;
  reward: number;             // Stars earned
  status: 'pending' | 'rewarded';
  created_at: Date;
}
```

### 5.10 Notification

```
ts
interface Notification {
  id: string;
  user_id: string;
  type: 'premium_activated' | 'new_episode' | 'discount' | 'referral_reward';
  title: { en: string; uk: string; ru: string };
  body: { en: string; uk: string; ru: string };
  data?: Record<string, any>;
  is_read: boolean;
  created_at: Date;
}
```

---

## 6. API Endpoints

### 6.1 Auth

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/telegram` | Authenticate with Telegram initData, returns JWT + user |
| GET | `/api/auth/me` | Get current user |
| POST | `/api/auth/refresh` | Refresh JWT token |

### 6.2 Anime

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/anime` | List anime (query: page, limit, genre, status, sort) |
| GET | `/api/anime/:id` | Anime detail with seasons + episodes |
| GET | `/api/anime/trending` | Trending anime |
| GET | `/api/anime/recommended` | Recommended for user |
| GET | `/api/anime/recent` | Recently added |
| GET | `/api/anime/continue-watching` | Continue watching for user |
| GET | `/api/anime/:id/episodes` | Episodes for anime |
| POST | `/api/anime/:id/like` | Like anime |
| POST | `/api/anime/:id/favorite` | Add/remove favorite |
| GET | `/api/anime/:id/related` | Related/recommendations |

### 6.3 Player

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/episodes/:id` | Episode detail (video URL, access check) |
| POST | `/api/episodes/:id/progress` | Save watch progress |
| GET | `/api/episodes/:id/next` | Get next episode |
| POST | `/api/episodes/:id/like` | Like episode |

### 6.4 Library

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/user/favorites` | User favorites |
| GET | `/api/user/history` | Watch history |
| GET | `/api/user/continue-watching` | Continue watching list |

### 6.5 Premium

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/premium/status` | Premium status + expiry |
| POST | `/api/premium/checkout` | Create Telegram Stars invoice (monthly/yearly) |
| POST | `/api/premium/season-pass/:animeId` | Purchase season pass |
| POST | `/api/webhooks/telegram-payment` | Telegram payment webhook (verify + grant) |

### 6.6 Referral

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/referral` | Referral info (code, count, rewards) |
| GET | `/api/referral/history` | Referral reward history |
| POST | `/api/referral/redeem` | Redeem reward |

### 6.7 Notifications

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/notifications` | User notifications |
| POST | `/api/notifications/:id/read` | Mark as read |
| POST | `/api/notifications/read-all` | Mark all as read |

### 6.8 Admin

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/admin/anime` | Upload/create anime |
| PUT | `/api/admin/anime/:id` | Update anime |
| DELETE | `/api/admin/anime/:id` | Delete anime |
| POST | `/api/admin/anime/:id/seasons` | Create season |
| POST | `/api/admin/anime/:id/episodes` | Create episode |
| POST | `/api/admin/users/:id/grant-premium` | Grant premium |
| POST | `/api/admin/users/:id/ban` | Ban user |
| GET | `/api/admin/stats` | Platform statistics |

---

### 6.9 Free Content Rule

- Episodes `1–3` of every anime → `is_free: true`
- Episodes `4+` → `is_free: false` (locked)
- Access check enforced server-side on `/api/episodes/:id`
- Client shows `PremiumOverlay` / `PremiumPopup` for locked content

---

## 7. Environment Variables

```
NEXT_PUBLIC_API_URL=            # Backend API base URL
NEXT_PUBLIC_TELEGRAM_BOT_TOKEN= # Telegram bot token (for payments webhook)
NEXT_PUBLIC_BOT_USERNAME=       # @AniFlowBot
NEXT_PUBLIC_REFERRAL_BOT_URL=   # t.me/AniFlowBot/start?ref=
DATABASE_URL=                   # PostgreSQL / Supabase
JWT_SECRET=                     # Auth signing secret
```

---

*End of STEP 1 — Architecture Specification.*
