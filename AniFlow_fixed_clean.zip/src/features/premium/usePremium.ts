import { useQuery, useMutation } from 'react-query';
import { paymentsService } from '@/services/payments.service';
import { useUserStore } from '@/store/userStore';
import type { PremiumStatus } from '@/types/premium';

export function usePremium() {
  const { user, setPremium } = useUserStore();

  const { data, isLoading } = useQuery(
    ['premium', 'status'],
    () => paymentsService.getPremiumStatus(),
    {
      onSuccess: (status: PremiumStatus) => {
        setPremium(status.is_premium, status.expires_at);
      },
    }
  );

  return {
    premiumStatus: data,
    isPremium: user?.is_premium ?? data?.is_premium ?? false,
    expiresAt: user?.premium_expires_at ?? data?.expires_at ?? null,
    isLoading,
  };
}

export function usePurchasePremium() {
  return useMutation((plan: 'monthly' | 'yearly') =>
    paymentsService.createCheckout(plan)
  );
}

export function usePurchaseSeasonPass() {
  return useMutation((animeId: string) =>
    paymentsService.purchaseSeasonPass(animeId)
  );
}

export function usePaymentHistory() {
  return useQuery(['premium', 'payments'], () => paymentsService.getPaymentHistory(), {
    staleTime: 60 * 1000,
  });
}

export function useRestorePurchases() {
  const { setPremium } = useUserStore();

  return useMutation(() => paymentsService.restorePurchases(), {
    onSuccess: (status: PremiumStatus) => {
      setPremium(status.is_premium, status.expires_at);
    },
  });
}
