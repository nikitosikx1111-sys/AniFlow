import { useQuery, useMutation } from 'react-query';
import { referralService } from '@/services/referral.service';
import type { ReferralInfo, ReferralReward } from '@/types/referral';

export function useReferral() {
  const { data, isLoading } = useQuery(
    ['referral', 'info'],
    () => referralService.getReferralInfo(),
    { staleTime: 5 * 60 * 1000 }
  );

  return {
    referralInfo: data as ReferralInfo | undefined,
    isLoading,
  };
}

export function useReferralHistory() {
  const { data, isLoading } = useQuery(
    ['referral', 'history'],
    () => referralService.getReferralHistory(),
    { staleTime: 5 * 60 * 1000 }
  );

  return {
    history: data as ReferralReward[] | undefined,
    isLoading,
  };
}

export function useRedeemReward() {
  return useMutation(() => referralService.redeemReward());
}
