import { useQuery, useMutation, useQueryClient } from 'react-query';
import { libraryService } from '@/services/library.service';
import { useLibraryStore } from '@/store/libraryStore';
import type { Anime } from '@/types/anime';
import type { ContinueWatchingItem } from '@/types/anime';

export function useFavorites() {
  const { favorites, addFavorite } = useLibraryStore();

  const { isLoading } = useQuery(
    ['library', 'favorites'],
    () => libraryService.getFavorites(),
    {
      onSuccess: (items: Anime[]) => {
        items.forEach((item) =>
          addFavorite({
            animeId: item.id,
            animeTitle: item.title.en,
            coverUrl: item.cover_url,
            addedAt: item.created_at,
          })
        );
      },
    }
  );

  return { favorites, isLoading };
}

export function useHistory() {
  const { history, addHistory } = useLibraryStore();

  const { isLoading } = useQuery(
    ['library', 'history'],
    () => libraryService.getHistory(),
    {
      onSuccess: (items: ContinueWatchingItem[]) => {
        items.forEach((item) =>
          addHistory({
            animeId: item.anime.id,
            episodeId: item.episode.id,
            animeTitle: item.anime.title.en,
            episodeTitle: item.episode.title.en,
            coverUrl: item.anime.cover_url,
            progress: item.progress,
            watchedAt: item.last_watched_at,
          })
        );
      },
    }
  );

  return { history, isLoading };
}

export function useContinueWatching() {
  const { continueWatching } = useLibraryStore();

  const { data, isLoading } = useQuery(
    ['library', 'continue'],
    () => libraryService.getContinueWatching(),
    { staleTime: 5 * 60 * 1000 }
  );

  const items: ContinueWatchingItem[] = data ?? [];
  return { continueWatching: items.length ? items : continueWatching, isLoading };
}

export function useRemoveFavorite() {
  const queryClient = useQueryClient();
  const { removeFavorite } = useLibraryStore();

  return useMutation((animeId: string) => libraryService.toggleFavorite(animeId), {
    onSuccess: (_, animeId) => {
      removeFavorite(animeId);
      queryClient.invalidateQueries(['library']);
    },
  });
}
