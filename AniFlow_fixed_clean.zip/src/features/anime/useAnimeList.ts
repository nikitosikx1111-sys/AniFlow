import { useInfiniteQuery } from 'react-query';
import { animeService } from '@/services/anime.service';
import type { AnimeListParams, AnimeListResponse } from '@/types/anime';

interface UseAnimeListOptions {
  params?: Partial<AnimeListParams>;
  enabled?: boolean;
}

export function useAnimeList({ params = {}, enabled = true }: UseAnimeListOptions = {}) {
  return useInfiniteQuery<AnimeListResponse>(
    ['anime', 'infinite', params],
    ({ pageParam = 1 }) =>
      animeService.getAnimeList({ page: pageParam as number, limit: params.limit ?? 10, ...params }),
    {
      getNextPageParam: (lastPage) => {
        if (!lastPage?.hasMore) return undefined;
        return lastPage.page + 1;
      },
      enabled,
      staleTime: 5 * 60 * 1000,
    }
  );
}
