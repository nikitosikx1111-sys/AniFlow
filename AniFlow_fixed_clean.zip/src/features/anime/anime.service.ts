import { animeService as service } from '@/services/anime.service';
import type { Anime, AnimeListParams, AnimeListResponse } from '@/types/anime';

export const animeFeatureService = {
  list: (params: AnimeListParams) => service.getAnimeList(params),
  detail: (id: string) => service.getAnimeDetail(id),
  trending: () => service.getTrending(),
  recommended: () => service.getRecommended(),
  recent: () => service.getRecent(),
  continueWatching: () => service.getContinueWatching(),
  episodes: (animeId: string) => service.getEpisodes(animeId),
  like: (animeId: string) => service.likeAnime(animeId),
  favorite: (animeId: string) => service.favoriteAnime(animeId),
  related: (animeId: string) => service.getRelated(animeId),
};

export type { Anime, AnimeListParams, AnimeListResponse };
