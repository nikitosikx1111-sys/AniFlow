import { useQuery, useMutation } from 'react-query';
import { authService } from '@/services/auth.service';
import { useUserStore } from '@/store/userStore';
import { useTelegram } from '@/hooks/useTelegram';

export function useAuth() {
  const { user, token, setUser, setToken, logout: clearUser } = useUserStore();
  const { initData } = useTelegram();

  const { data, isLoading, refetch } = useQuery(
    ['auth', 'me'],
    () => authService.getMe(),
    {
      enabled: !!token,
      retry: 1,
      onSuccess: (data) => setUser(data),
    }
  );

  const loginMutation = useMutation(
    () => authService.authenticate(initData || ''),
    {
      onSuccess: (data) => {
        setToken(data.token);
        setUser(data.user);
      },
    }
  );

  const logout = () => {
    clearUser();
  };

  return {
    user: user || data,
    isLoading,
    isAuthenticated: !!token && !!(user?.id || data?.id),
    login: loginMutation.mutate,
    isLoggingIn: loginMutation.isLoading,
    logout,
    refetch,
  };
}
