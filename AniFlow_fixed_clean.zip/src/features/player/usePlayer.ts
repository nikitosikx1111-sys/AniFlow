import { useQuery, useMutation } from 'react-query';
import { playerService } from '@/services/player.service';
import { usePlayerStore } from '@/store/playerStore';
import type { Episode } from '@/types/episode';

export function usePlayer(episodeId: string) {
  const {
    setEpisode,
    setPlaying,
    setCurrentTime,
    setPlaybackRate,
    setMuted,
    setFullscreen,
  } = usePlayerStore();

  const { data: episode, isLoading, error } = useQuery<Episode>(
    ['player', 'episode', episodeId],
    () => playerService.getEpisode(episodeId),
    {
      onSuccess: (data) => {
        setEpisode(data.id, data.anime_id);
      },
    }
  );

  const saveProgress = useMutation(
    ({ episodeId: id, progress }: { episodeId: string; progress: number }) =>
      playerService.saveProgress(id, progress),
    {
      onSuccess: (_, variables) => {
        const { duration } = usePlayerStore.getState();
        setCurrentTime(variables.progress * duration, duration);
      },
    }
  );

  const getNextEpisode = useQuery<Episode | null>(
    ['player', 'next', episodeId],
    () => playerService.getNextEpisode(episodeId),
    { enabled: false }
  );

  return {
    episode,
    isLoading,
    error,
    saveProgress: saveProgress.mutate,
    getNextEpisode: getNextEpisode.refetch,
    controls: {
      setPlaying,
      setCurrentTime,
      setPlaybackRate,
      setMuted,
      setFullscreen,
    },
  };
}
