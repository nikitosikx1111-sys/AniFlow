'use client';

import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { getNestedValue, locales, defaultLanguage } from './index';
import type { Language } from '@/types/user';
import { useTelegram } from '@/hooks/useTelegram';

interface LanguageContextValue {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextValue | undefined>(undefined);

const STORAGE_KEY = 'aniflow_language';

function detectLanguage(telegramLang?: string): Language {
  if (!telegramLang) return defaultLanguage;
  const lang = telegramLang.toLowerCase().split('-')[0];
  if (lang === 'uk' || lang === 'ru') return lang as Language;
  return defaultLanguage;
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const { user } = useTelegram();
  const [language, setLanguageState] = useState<Language>(defaultLanguage);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY) as Language | null;
    if (saved && saved in locales) {
      setLanguageState(saved);
    } else {
      const detected = detectLanguage(user?.language_code);
      setLanguageState(detected);
    }
  }, [user?.language_code]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem(STORAGE_KEY, lang);
  };

  const t = useMemo(() => {
    return (key: string): string => {
      const dict = locales[language];
      const value = getNestedValue(dict as unknown as Record<string, unknown>, key);
      return typeof value === 'string' ? value : key;
    };
  }, [language]);

  const value = useMemo(
    () => ({ language, setLanguage, t }),
    [language, t]
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
}
