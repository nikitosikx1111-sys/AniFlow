import en from './locales/en';
import uk from './locales/uk';
import ru from './locales/ru';
import type { Language } from '@/types/user';

export const locales = {
  en,
  uk,
  ru,
} as const;

export type Locale = keyof typeof locales;
export type TranslationKey = string;

export const defaultLanguage: Language = 'en';

export const languages: { code: Language; label: string; native: string }[] = [
  { code: 'en', label: 'English', native: 'English' },
  { code: 'uk', label: 'Ukrainian', native: 'Українська' },
  { code: 'ru', label: 'Russian', native: 'Русский' },
];

export function getNestedValue(obj: Record<string, unknown>, path: string): unknown {
  return path.split('.').reduce<unknown>((acc, key) => {
    if (acc && typeof acc === 'object' && key in acc) {
      return (acc as Record<string, unknown>)[key];
    }
    return undefined;
  }, obj);
}

export { en, uk, ru };
