'use client';

import { useRef, useCallback, useEffect, type TouchEvent } from 'react';

interface SwipeHandlers {
  onSwipeUp?: () => void;
  onSwipeDown?: () => void;
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
}

interface SwipeOptions {
  threshold?: number;
  preventVerticalScroll?: boolean;
  disabled?: boolean;
}

export function useSwipe(
  handlers: SwipeHandlers,
  options: SwipeOptions = {}
) {
  const { threshold = 80, preventVerticalScroll = false, disabled = false } = options;
  const startX = useRef(0);
  const startY = useRef(0);
  const isTracking = useRef(false);
  const handlersRef = useRef(handlers);

  useEffect(() => {
    handlersRef.current = handlers;
  }, [handlers]);

  const onTouchStart = useCallback((e: TouchEvent) => {
    if (disabled) return;
    const touch = e.touches[0];
    startX.current = touch.clientX;
    startY.current = touch.clientY;
    isTracking.current = true;
  }, [disabled]);

  const onTouchMove = useCallback(
    (e: TouchEvent) => {
      if (disabled || !isTracking.current) return;
      const touch = e.touches[0];
      const deltaX = touch.clientX - startX.current;
      const deltaY = touch.clientY - startY.current;

      if (preventVerticalScroll && deltaY > 0 && Math.abs(deltaY) > Math.abs(deltaX)) {
        e.preventDefault();
      }
    },
    [disabled, preventVerticalScroll]
  );

  const onTouchEnd = useCallback(
    (e: TouchEvent) => {
      if (disabled || !isTracking.current) return;
      isTracking.current = false;

      const touch = e.changedTouches[0];
      const deltaX = touch.clientX - startX.current;
      const deltaY = touch.clientY - startY.current;

      if (Math.abs(deltaY) > Math.abs(deltaX)) {
        if (Math.abs(deltaY) > threshold) {
          if (deltaY < 0) {
            handlersRef.current.onSwipeUp?.();
          } else {
            handlersRef.current.onSwipeDown?.();
          }
        }
      } else {
        if (Math.abs(deltaX) > threshold) {
          if (deltaX < 0) {
            handlersRef.current.onSwipeLeft?.();
          } else {
            handlersRef.current.onSwipeRight?.();
          }
        }
      }
    },
    [disabled, threshold]
  );

  return {
    onTouchStart,
    onTouchMove,
    onTouchEnd,
  };
}
