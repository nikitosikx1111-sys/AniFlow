import { apiClient } from '@/lib/api-client';
import { API_CONFIG } from '@/config/api';
import type { Anime } from '@/types/anime';
import type { ContinueWatchingItem } from '@/types/anime';

export const libraryService = {
  async getFavorites(): Promise<Anime[]> {
    return apiClient.get<Anime[]>(API_CONFIG.endpoints.library.favorites);
  },

  async getHistory(): Promise<ContinueWatchingItem[]> {
    return apiClient.get<ContinueWatchingItem[]>(API_CONFIG.endpoints.library.history);
  },

  async getContinueWatching(): Promise<ContinueWatchingItem[]> {
    return apiClient.get<ContinueWatchingItem[]>(API_CONFIG.endpoints.library.continueWatching);
  },

  async toggleFavorite(animeId: string): Promise<void> {
    return apiClient.post<void>(API_CONFIG.endpoints.anime.favorite(animeId));
  },
};
