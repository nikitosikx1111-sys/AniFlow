import { apiClient } from '@/lib/api-client';
import { API_CONFIG } from '@/config/api';
import type { Anime } from '@/types/anime';
import type { Episode } from '@/types/episode';

export interface AdminStats {
  totalUsers: number;
  totalAnime: number;
  totalViews: number;
  totalLikes: number;
  premiumUsers: number;
  activeSubscriptions: number;
  revenue: number;
  dailyViews: { date: string; views: number }[];
}

export const adminService = {
  async uploadAnime(data: Partial<Anime>): Promise<Anime> {
    return apiClient.post<Anime>(API_CONFIG.endpoints.admin.anime, data);
  },

  async updateAnime(id: string, data: Partial<Anime>): Promise<Anime> {
    return apiClient.put<Anime>(`${API_CONFIG.endpoints.admin.anime}/${id}`, data);
  },

  async deleteAnime(id: string): Promise<void> {
    return apiClient.delete<void>(`${API_CONFIG.endpoints.admin.anime}/${id}`);
  },

  async setAnimeHidden(id: string, hidden: boolean): Promise<Anime> {
    return apiClient.patch<Anime>(API_CONFIG.endpoints.admin.hideAnime(id), { hidden });
  },

  async uploadCover(animeId: string, file: File): Promise<{ cover_url: string }> {
    const formData = new FormData();
    formData.append('file', file);
    return apiClient.post<{ cover_url: string }>(
      API_CONFIG.endpoints.admin.uploadCover(animeId),
      formData
    );
  },

  async createSeason(animeId: string, data: { number: number; title: Record<string, string> }): Promise<void> {
    return apiClient.post<void>(API_CONFIG.endpoints.admin.season(animeId), data);
  },

  async createEpisode(animeId: string, data: Partial<Episode>): Promise<Episode> {
    return apiClient.post<Episode>(API_CONFIG.endpoints.admin.episode(animeId), data);
  },

  async uploadVideo(episodeId: string, file: File): Promise<{ video_url: string }> {
    const formData = new FormData();
    formData.append('file', file);
    return apiClient.post<{ video_url: string }>(
      API_CONFIG.endpoints.admin.uploadVideo(episodeId),
      formData
    );
  },

  async scheduleEpisode(episodeId: string, scheduledAt: string): Promise<Episode> {
    return apiClient.patch<Episode>(
      API_CONFIG.endpoints.admin.scheduleEpisode(episodeId),
      { scheduled_at: scheduledAt }
    );
  },

  async grantPremium(userId: string): Promise<void> {
    return apiClient.post<void>(API_CONFIG.endpoints.admin.grantPremium(userId));
  },

  async banUser(userId: string): Promise<void> {
    return apiClient.post<void>(API_CONFIG.endpoints.admin.ban(userId));
  },

  async getStats(): Promise<AdminStats> {
    return apiClient.get<AdminStats>(API_CONFIG.endpoints.admin.stats);
  },
};
