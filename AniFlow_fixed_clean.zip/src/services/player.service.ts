import { apiClient } from '@/lib/api-client';
import { API_CONFIG } from '@/config/api';
import type { Episode } from '@/types/episode';

export const playerService = {
  async getEpisode(episodeId: string): Promise<Episode> {
    return apiClient.get<Episode>(API_CONFIG.endpoints.player.episode(episodeId));
  },

  async saveProgress(episodeId: string, progress: number): Promise<void> {
    return apiClient.post<void>(API_CONFIG.endpoints.player.progress(episodeId), {
      progress,
    });
  },

  async getNextEpisode(episodeId: string): Promise<Episode | null> {
    return apiClient.get<Episode | null>(API_CONFIG.endpoints.player.next(episodeId));
  },

  async likeEpisode(episodeId: string): Promise<void> {
    return apiClient.post<void>(API_CONFIG.endpoints.player.like(episodeId));
  },
};
