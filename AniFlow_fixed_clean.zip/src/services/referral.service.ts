import { apiClient } from '@/lib/api-client';
import { API_CONFIG } from '@/config/api';
import type { ReferralHistoryItem, ReferralInfo, ReferralReward } from '@/types/referral';

export const referralService = {
  async getReferralInfo(): Promise<ReferralInfo> {
    return apiClient.get<ReferralInfo>(API_CONFIG.endpoints.referral.info);
  },

  async getReferralHistory(): Promise<ReferralHistoryItem[]> {
    return apiClient.get<ReferralHistoryItem[]>(API_CONFIG.endpoints.referral.history);
  },

  async redeemReward(): Promise<ReferralReward> {
    return apiClient.post<ReferralReward>(API_CONFIG.endpoints.referral.redeem);
  },
};
