import { apiClient } from '@/lib/api-client';
import { API_CONFIG } from '@/config/api';
import type { AppNotification } from '@/types/notification';

export const notificationsService = {
  async getNotifications(): Promise<AppNotification[]> {
    return apiClient.get<AppNotification[]>(API_CONFIG.endpoints.notifications.list);
  },

  async markAsRead(id: string): Promise<void> {
    return apiClient.post<void>(API_CONFIG.endpoints.notifications.read(id));
  },

  async markAllAsRead(): Promise<void> {
    return apiClient.post<void>(API_CONFIG.endpoints.notifications.readAll);
  },
};
