import { apiClient } from '@/lib/api-client';
import { API_CONFIG } from '@/config/api';
import type { PremiumStatus, CheckoutResponse, PaymentHistoryItem } from '@/types/premium';

export const paymentsService = {
  async getPremiumStatus(): Promise<PremiumStatus> {
    return apiClient.get<PremiumStatus>(API_CONFIG.endpoints.premium.status);
  },

  async createCheckout(plan: 'monthly' | 'yearly'): Promise<CheckoutResponse> {
    return apiClient.post<CheckoutResponse>(API_CONFIG.endpoints.premium.checkout, {
      plan,
    });
  },

  async confirmPurchase(invoiceId: string): Promise<PremiumStatus> {
    return apiClient.post<PremiumStatus>(API_CONFIG.endpoints.premium.confirm, {
      invoice_id: invoiceId,
    });
  },

  async getPaymentHistory(): Promise<PaymentHistoryItem[]> {
    return apiClient.get<PaymentHistoryItem[]>(API_CONFIG.endpoints.premium.history);
  },

  async restorePurchases(): Promise<PremiumStatus> {
    return apiClient.post<PremiumStatus>(API_CONFIG.endpoints.premium.restore);
  },

  async purchaseSeasonPass(animeId: string): Promise<CheckoutResponse> {
    return apiClient.post<CheckoutResponse>(
      API_CONFIG.endpoints.premium.seasonPass(animeId)
    );
  },
};
