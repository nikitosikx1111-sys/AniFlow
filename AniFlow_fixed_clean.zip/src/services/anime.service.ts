import { apiClient } from '@/lib/api-client';
import { API_CONFIG } from '@/config/api';
import type { Anime, AnimeListParams, AnimeListResponse } from '@/types/anime';
import type { Episode } from '@/types/episode';

export const animeService = {
  async getAnimeList(params: AnimeListParams): Promise<AnimeListResponse> {
    const query = new URLSearchParams();
    if (params.page) query.set('page', String(params.page));
    if (params.limit) query.set('limit', String(params.limit));
    if (params.genre) query.set('genre', params.genre);
    if (params.status) query.set('status', params.status);
    if (params.sort) query.set('sort', params.sort);
    if (params.search) query.set('search', params.search);

    const url = `${API_CONFIG.endpoints.anime.list}?${query.toString()}`;
    return apiClient.get<AnimeListResponse>(url);
  },

  async getAnimeDetail(id: string): Promise<Anime> {
    return apiClient.get<Anime>(API_CONFIG.endpoints.anime.detail(id));
  },

  async getTrending(): Promise<Anime[]> {
    return apiClient.get<Anime[]>(API_CONFIG.endpoints.anime.trending);
  },

  async getRecommended(): Promise<Anime[]> {
    return apiClient.get<Anime[]>(API_CONFIG.endpoints.anime.recommended);
  },

  async getRecent(): Promise<Anime[]> {
    return apiClient.get<Anime[]>(API_CONFIG.endpoints.anime.recent);
  },

  async getContinueWatching(): Promise<Anime[]> {
    return apiClient.get<Anime[]>(API_CONFIG.endpoints.anime.continueWatching);
  },

  async getEpisodes(animeId: string): Promise<Episode[]> {
    return apiClient.get<Episode[]>(API_CONFIG.endpoints.anime.episodes(animeId));
  },

  async likeAnime(animeId: string): Promise<void> {
    return apiClient.post<void>(API_CONFIG.endpoints.anime.like(animeId));
  },

  async favoriteAnime(animeId: string): Promise<void> {
    return apiClient.post<void>(API_CONFIG.endpoints.anime.favorite(animeId));
  },

  async getRelated(animeId: string): Promise<Anime[]> {
    return apiClient.get<Anime[]>(API_CONFIG.endpoints.anime.related(animeId));
  },
};
