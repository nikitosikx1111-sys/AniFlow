import type { TelegramUser } from '@/types/user';

interface TelegramInitData {
  user?: TelegramUser;
  start_param?: string;
  auth_date?: number;
  hash?: string;
}

export const telegramService = {
  getWebApp() {
    return window.Telegram?.WebApp ?? null;
  },

  getInitData(): string {
    return window.Telegram?.WebApp?.initData ?? '';
  },

  getInitDataUnsafe(): TelegramInitData {
    return window.Telegram?.WebApp?.initDataUnsafe ?? {};
  },

  getUser(): TelegramUser | null {
    return window.Telegram?.WebApp?.initDataUnsafe?.user ?? null;
  },

  getStartParam(): string | null {
    return window.Telegram?.WebApp?.initDataUnsafe?.start_param ?? null;
  },

  ready() {
    window.Telegram?.WebApp?.ready();
  },

  expand() {
    window.Telegram?.WebApp?.expand();
  },

  close() {
    window.Telegram?.WebApp?.close();
  },

  setColors(header: string, background: string) {
    window.Telegram?.WebApp?.setHeaderColor(header);
    window.Telegram?.WebApp?.setBackgroundColor(background);
  },

  hapticImpact(style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft' = 'medium') {
    window.Telegram?.WebApp?.HapticFeedback?.impactOccurred(style);
  },

  hapticNotification(type: 'error' | 'success' | 'warning' = 'success') {
    window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred(type);
  },

  hapticSelection() {
    window.Telegram?.WebApp?.HapticFeedback?.selectionChanged();
  },

  showAlert(message: string) {
    window.Telegram?.WebApp?.showAlert(message);
  },

  showConfirm(message: string): Promise<boolean> {
    return new Promise((resolve) => {
      window.Telegram?.WebApp?.showConfirm(message, resolve);
    });
  },

  openLink(url: string) {
    window.Telegram?.WebApp?.openLink(url);
  },

  openTelegramLink(url: string) {
    window.Telegram?.WebApp?.openTelegramLink(url);
  },

  mainButton(text: string, onClick: () => void) {
    const btn = window.Telegram?.WebApp?.MainButton as any;
    if (!btn) return;
    btn.setText(text);
    btn.show();
    btn.onClick?.(onClick);
  },

  hideMainButton() {
    window.Telegram?.WebApp?.MainButton?.hide();
  },

  backButton(onClick: () => void) {
    const btn = window.Telegram?.WebApp?.BackButton;
    if (!btn) return;
    btn.show();
    btn.onClick(onClick);
  },

  hideBackButton() {
    window.Telegram?.WebApp?.BackButton?.hide();
  },
};
