import { apiClient } from '@/lib/api-client';
import { API_CONFIG } from '@/config/api';
import type { User } from '@/types/user';

interface AuthResponse {
  token: string;
  user: User;
}

export const authService = {
  async authenticate(initData: string): Promise<AuthResponse> {
    return apiClient.post<AuthResponse>(API_CONFIG.endpoints.auth.telegram, {
      initData,
    });
  },

  async getMe(): Promise<User> {
    return apiClient.get<User>(API_CONFIG.endpoints.auth.me);
  },

  async refreshToken(): Promise<{ token: string }> {
    return apiClient.post<{ token: string }>(API_CONFIG.endpoints.auth.refresh);
  },
};
