'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, Language } from '@/types/user';

interface UserState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  setUser: (user: User | null) => void;
  setToken: (token: string | null) => void;
  setLanguage: (language: Language) => void;
  setPremium: (isPremium: boolean, expiresAt?: string) => void;
  logout: () => void;
}

export const useUserStore = create<UserState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,

      setUser: (user) =>
        set({
          user,
          isAuthenticated: !!user,
        }),

      setToken: (token) =>
        set({
          token,
          isAuthenticated: !!token,
        }),

      setLanguage: (language) =>
        set((state) => ({
          user: state.user ? { ...state.user, language } : null,
        })),

      setPremium: (isPremium, expiresAt) =>
        set((state) => ({
          user: state.user
            ? {
                ...state.user,
                is_premium: isPremium,
                premium_expires_at: expiresAt,
              }
            : null,
        })),

      logout: () =>
        set({
          user: null,
          token: null,
          isAuthenticated: false,
        }),
    }),
    {
      name: 'aniflow_user',
    }
  )
);
