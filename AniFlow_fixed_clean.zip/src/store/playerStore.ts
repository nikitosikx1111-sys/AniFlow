'use client';

import { create } from 'zustand';

interface PlayerState {
  currentEpisodeId: string | null;
  currentAnimeId: string | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  playbackRate: number;
  isMuted: boolean;
  isFullscreen: boolean;
  progress: number;
  autoNext: boolean;
  setEpisode: (episodeId: string, animeId: string) => void;
  setPlaying: (isPlaying: boolean) => void;
  setCurrentTime: (time: number, duration: number) => void;
  setPlaybackRate: (rate: number) => void;
  setMuted: (isMuted: boolean) => void;
  setFullscreen: (isFullscreen: boolean) => void;
  setAutoNext: (autoNext: boolean) => void;
  reset: () => void;
}

export const usePlayerStore = create<PlayerState>((set) => ({
  currentEpisodeId: null,
  currentAnimeId: null,
  isPlaying: false,
  currentTime: 0,
  duration: 0,
  playbackRate: 1,
  isMuted: false,
  isFullscreen: false,
  progress: 0,
  autoNext: true,

  setEpisode: (episodeId, animeId) =>
    set({
      currentEpisodeId: episodeId,
      currentAnimeId: animeId,
      currentTime: 0,
      duration: 0,
      progress: 0,
      isPlaying: false,
    }),

  setPlaying: (isPlaying) => set({ isPlaying }),

  setCurrentTime: (currentTime, duration) =>
    set({
      currentTime,
      duration,
      progress: duration > 0 ? (currentTime / duration) * 100 : 0,
    }),

  setPlaybackRate: (playbackRate) => set({ playbackRate }),

  setMuted: (isMuted) => set({ isMuted }),

  setFullscreen: (isFullscreen) => set({ isFullscreen }),

  setAutoNext: (autoNext) => set({ autoNext }),

  reset: () =>
    set({
      currentEpisodeId: null,
      currentAnimeId: null,
      isPlaying: false,
      currentTime: 0,
      duration: 0,
      playbackRate: 1,
      isMuted: false,
      isFullscreen: false,
      progress: 0,
      autoNext: true,
    }),
}));
