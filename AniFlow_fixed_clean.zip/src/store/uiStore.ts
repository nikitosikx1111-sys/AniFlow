'use client';

import { create } from 'zustand';
import type { ThemeMode } from '@/config/themes';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
}

interface UIState {
  theme: ThemeMode;
  isBottomNavVisible: boolean;
  toasts: Toast[];
  isPremiumModalOpen: boolean;
  premiumModalAnimeId: string | null;
  isSeasonPassModalOpen: boolean;
  seasonPassModalAnimeId: string | null;
  setTheme: (theme: ThemeMode) => void;
  setBottomNavVisible: (visible: boolean) => void;
  showToast: (message: string, type?: Toast['type']) => void;
  hideToast: (id: string) => void;
  openPremiumModal: (animeId?: string) => void;
  closePremiumModal: () => void;
  openSeasonPassModal: (animeId?: string) => void;
  closeSeasonPassModal: () => void;
}

export const useUIStore = create<UIState>((set) => ({
  theme: 'dark',
  isBottomNavVisible: true,
  toasts: [],
  isPremiumModalOpen: false,
  premiumModalAnimeId: null,
  isSeasonPassModalOpen: false,
  seasonPassModalAnimeId: null,

  setTheme: (theme) => set({ theme }),

  setBottomNavVisible: (isBottomNavVisible) => set({ isBottomNavVisible }),

  showToast: (message, type = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    set((state) => ({
      toasts: [...state.toasts, { id, message, type }],
    }));
    setTimeout(() => {
      set((state) => ({
        toasts: state.toasts.filter((t) => t.id !== id),
      }));
    }, 3000);
  },

  hideToast: (id) =>
    set((state) => ({
      toasts: state.toasts.filter((t) => t.id !== id),
    })),

  openPremiumModal: (animeId) =>
    set({
      isPremiumModalOpen: true,
      premiumModalAnimeId: animeId ?? null,
    }),

  closePremiumModal: () =>
    set({
      isPremiumModalOpen: false,
      premiumModalAnimeId: null,
    }),

  openSeasonPassModal: (animeId) =>
    set({
      isSeasonPassModalOpen: true,
      seasonPassModalAnimeId: animeId ?? null,
    }),

  closeSeasonPassModal: () =>
    set({
      isSeasonPassModalOpen: false,
      seasonPassModalAnimeId: null,
    }),
}));
