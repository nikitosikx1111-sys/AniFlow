'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { ContinueWatchingItem } from '@/types/anime';

interface LibraryItem {
  animeId: string;
  animeTitle: string;
  coverUrl: string;
  addedAt: string;
}

interface HistoryItem {
  animeId: string;
  episodeId: string;
  animeTitle: string;
  episodeTitle: string;
  coverUrl: string;
  progress: number;
  watchedAt: string;
}

interface LibraryState {
  favorites: LibraryItem[];
  history: HistoryItem[];
  continueWatching: ContinueWatchingItem[];
  addFavorite: (item: LibraryItem) => void;
  removeFavorite: (animeId: string) => void;
  isFavorite: (animeId: string) => boolean;
  addHistory: (item: HistoryItem) => void;
  addContinueWatching: (item: ContinueWatchingItem) => void;
  removeContinueWatching: (episodeId: string) => void;
  clearHistory: () => void;
}

export const useLibraryStore = create<LibraryState>()(
  persist(
    (set, get) => ({
      favorites: [],
      history: [],
      continueWatching: [],

      addFavorite: (item) =>
        set((state) => {
          if (state.favorites.some((f) => f.animeId === item.animeId)) {
            return state;
          }
          return { favorites: [item, ...state.favorites] };
        }),

      removeFavorite: (animeId) =>
        set((state) => ({
          favorites: state.favorites.filter((f) => f.animeId !== animeId),
        })),

      isFavorite: (animeId) => get().favorites.some((f) => f.animeId === animeId),

      addHistory: (item) =>
        set((state) => ({
          history: [
            item,
            ...state.history.filter((h) => h.episodeId !== item.episodeId),
          ].slice(0, 50),
        })),

      addContinueWatching: (item) =>
        set((state) => ({
          continueWatching: [
            item,
            ...state.continueWatching.filter((current) => current.episode.id !== item.episode.id),
          ].slice(0, 30),
        })),

      removeContinueWatching: (episodeId) =>
        set((state) => ({
          continueWatching: state.continueWatching.filter((item) => item.episode.id !== episodeId),
        })),

      clearHistory: () => set({ history: [] }),
    }),
    {
      name: 'aniflow_library',
    }
  )
);
