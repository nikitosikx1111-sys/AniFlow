type ImpactStyle = 'light' | 'medium' | 'heavy' | 'rigid' | 'soft';
type NotificationType = 'error' | 'success' | 'warning';

interface HapticFeedback {
  impactOccurred: (style: ImpactStyle) => void;
  notificationOccurred: (type: NotificationType) => void;
  selectionChanged: () => void;
}

function getHaptic(): HapticFeedback | undefined {
  return window.Telegram?.WebApp?.HapticFeedback;
}

export const haptics = {
  impact(style: ImpactStyle = 'medium') {
    getHaptic()?.impactOccurred(style);
  },
  notification(type: NotificationType = 'success') {
    getHaptic()?.notificationOccurred(type);
  },
  selection() {
    getHaptic()?.selectionChanged();
  },
};
