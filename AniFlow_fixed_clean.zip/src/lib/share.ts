const BOT_USERNAME = process.env.NEXT_PUBLIC_BOT_USERNAME ?? 'AniFlowBot';

export function buildShareUrl(
  animeId: string,
  episodeNumber?: number
): string {
  const base = `https://t.me/${BOT_USERNAME}/aniflow`;
  const params = new URLSearchParams({ anime: animeId });
  if (episodeNumber) {
    params.set('ep', String(episodeNumber));
  }
  return `${base}?${params.toString()}`;
}

export function buildReferralUrl(code: string): string {
  const base = process.env.NEXT_PUBLIC_REFERRAL_BOT_URL ?? `https://t.me/${BOT_USERNAME}/start`;
  return `${base}ref=${code}`;
}

export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
    // Fallback for Telegram WebView
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
    return true;
  } catch {
    return false;
  }
}

export function shareAnime(animeId: string, title: string): void {
  const url = buildShareUrl(animeId);
  const text = `Check out ${title} on AniFlow!`;
  const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`;
  window.Telegram?.WebApp?.openTelegramLink(shareUrl);
}
