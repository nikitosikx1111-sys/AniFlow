const PREFIX = 'aniflow_';

export const storage = {
  get<T>(key: string, fallback: T): T {
    try {
      const value = localStorage.getItem(PREFIX + key);
      return value ? (JSON.parse(value) as T) : fallback;
    } catch {
      return fallback;
    }
  },

  set<T>(key: string, value: T): void {
    try {
      localStorage.setItem(PREFIX + key, JSON.stringify(value));
    } catch {
      // Storage full or unavailable
    }
  },

  remove(key: string): void {
    try {
      localStorage.removeItem(PREFIX + key);
    } catch {
      // Ignore
    }
  },

  clear(): void {
    try {
      localStorage.clear();
    } catch {
      // Ignore
    }
  },
};
