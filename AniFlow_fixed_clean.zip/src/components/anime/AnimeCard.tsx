'use client';

import { cn, formatNumber } from '@/lib/utils';
import { useLanguage } from '@/i18n/LanguageProvider';
import { Badge } from '@/components/common/Badge';
import { Star, Play, Lock, Eye } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import type { Anime } from '@/types/anime';

interface AnimeCardProps {
  anime: Anime;
  className?: string;
  priority?: boolean;
}

export function AnimeCard({ anime, className, priority = false }: AnimeCardProps) {
  const { t } = useLanguage();

  return (
    <Link
      href={`/anime/${anime.id}`}
      className={cn(
        'group relative block overflow-hidden rounded-2xl bg-surface border border-border/50',
        'transition-all duration-300 hover:border-primary/40 hover:shadow-neon hover:-translate-y-1',
        className
      )}
    >
      {/* Cover image */}
      <div className="relative aspect-[2/3] overflow-hidden">
        <Image
          src={anime.cover_url}
          alt={anime.title.en}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-110"
          sizes="(max-width: 768px) 50vw, 25vw"
          priority={priority}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

        {/* Top badges */}
        <div className="absolute top-2 left-2 right-2 flex items-start justify-between">
          {anime.is_premium && <Badge variant="premium">{t('home.premiumBadge')}</Badge>}
          <Badge variant="hot" className="ml-auto">
            <Star className="w-3 h-3 fill-current" />
            {anime.rating.toFixed(1)}
          </Badge>
        </div>

        {/* Bottom overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-3">
          <h3 className="text-sm font-semibold text-white mb-1 line-clamp-2">
            {anime.title.en}
          </h3>
          <div className="flex items-center gap-2 text-[10px] text-white/60">
            <span className="flex items-center gap-0.5">
              <Eye className="w-3 h-3" />
              {formatNumber(anime.views)}
            </span>
            <span className="flex items-center gap-0.5">
              <Play className="w-3 h-3" />
              {anime.genres[0] ?? 'Anime'}
            </span>
          </div>
        </div>
      </div>

      {/* Premium lock overlay on hover */}
      {anime.is_premium && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-primary/20 backdrop-blur-sm border border-primary/30">
            <Lock className="w-4 h-4 text-primary-light" />
            <span className="text-xs font-medium text-white">{t('anime.premium')}</span>
          </div>
        </div>
      )}
    </Link>
  );
}
