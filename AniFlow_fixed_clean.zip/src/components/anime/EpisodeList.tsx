'use client';

import { cn, formatDuration } from '@/lib/utils';
import { useLanguage } from '@/i18n/LanguageProvider';
import { useHaptic } from '@/hooks/useHaptic';
import { Badge } from '@/components/common/Badge';
import { Lock, Play, Eye, Clock } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import type { Episode } from '@/types/episode';

interface EpisodeListProps {
  episodes: Episode[];
  animeId: string;
  isPremiumUser?: boolean;
  currentEpisodeId?: string;
  onEpisodeClick?: (episode: Episode) => void;
}

export function EpisodeList({
  episodes,
  isPremiumUser = false,
  currentEpisodeId,
  onEpisodeClick,
}: EpisodeListProps) {
  const { t } = useLanguage();
  const { impact } = useHaptic();

  const handleClick = (episode: Episode) => {
    impact('light');
    onEpisodeClick?.(episode);
  };

  return (
    <div className="space-y-2">
      {episodes.map((episode) => {
        const isLocked = !episode.is_free && !isPremiumUser;
        const isCurrent = episode.id === currentEpisodeId;
        const progress = episode.progress ?? 0;

        return (
          <Link
            key={episode.id}
            href={`/watch/${episode.id}`}
            onClick={() => handleClick(episode)}
            className={cn(
              'flex items-center gap-3 p-3 rounded-2xl border transition-all',
              'bg-surface/60 backdrop-blur-xl border-border/50',
              isCurrent
                ? 'border-primary/50 shadow-neon'
                : 'hover:border-primary/30 hover:bg-surface2/60',
              isLocked && 'opacity-80'
            )}
          >
            {/* Thumbnail */}
            <div className="relative w-28 h-16 flex-shrink-0 overflow-hidden rounded-xl">
              <Image
                src={episode.thumbnail_url}
                alt={episode.title.en}
                fill
                sizes="112px"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/30" />
              <div className="absolute inset-0 flex items-center justify-center">
                {isLocked ? (
                  <div className="p-2 rounded-full bg-black/50">
                    <Lock className="w-4 h-4 text-white" />
                  </div>
                ) : (
                  <div className="p-2 rounded-full bg-black/50">
                    <Play className="w-4 h-4 text-white fill-current" />
                  </div>
                )}
              </div>

              {/* Progress bar */}
              {progress > 0 && progress < 100 && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-white/20">
                  <div
                    className="h-full bg-primary"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              )}
            </div>

            {/* Episode info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <Badge variant="episode">
                  {t('home.episode')} {episode.number}
                </Badge>
                {!episode.is_free && <Badge variant="premium">{t('common.premium')}</Badge>}
              </div>
              <h4 className="text-sm font-medium text-text-primary truncate">
                {episode.title.en}
              </h4>
              <div className="flex items-center gap-3 text-xs text-text-muted mt-1">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {formatDuration(episode.duration)}
                </span>
                <span className="flex items-center gap-1">
                  <Eye className="w-3 h-3" />
                  {episode.views}
                </span>
              </div>
            </div>
          </Link>
        );
      })}
    </div>
  );
}
