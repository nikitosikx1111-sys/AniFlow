'use client';

import { AnimeCard } from './AnimeCard';
import { Skeleton } from '@/components/common/Skeleton';
import { useInfiniteScroll } from '@/hooks/useInfiniteScroll';
import { cn } from '@/lib/utils';
import type { Anime } from '@/types/anime';

interface AnimeGridProps {
  items: Anime[];
  isLoading?: boolean;
  hasMore?: boolean;
  onLoadMore?: () => void;
  className?: string;
  columns?: number;
}

export function AnimeGrid({
  items,
  isLoading = false,
  hasMore = false,
  onLoadMore,
  className,
  columns = 3,
}: AnimeGridProps) {
  const { sentinelRef } = useInfiniteScroll({
    hasMore,
    isLoading,
    onLoadMore: onLoadMore ?? (() => {}),
  });

  const getColumns = () => {
    switch (columns) {
      case 2:
        return 'grid-cols-2';
      case 4:
        return 'grid-cols-4';
      case 5:
        return 'grid-cols-5';
      default:
        return 'grid-cols-3';
    }
  };

  return (
    <div className={cn('relative', className)}>
      <div className={cn('grid gap-3', getColumns())}>
        {items.map((anime, idx) => (
          <AnimeCard key={anime.id} anime={anime} priority={idx < 6} />
        ))}

        {isLoading &&
          Array.from({ length: columns * 2 }).map((_, idx) => (
            <div key={`skeleton-${idx}`} className="space-y-2">
              <Skeleton className="aspect-[2/3] w-full" />
              <Skeleton variant="text" className="w-3/4" />
              <Skeleton variant="text" className="w-1/2" />
            </div>
          ))}
      </div>

      {hasMore && <div ref={sentinelRef} className="h-4" />}

      {!isLoading && items.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <p className="text-text-muted text-sm">No anime found</p>
        </div>
      )}
    </div>
  );
}
