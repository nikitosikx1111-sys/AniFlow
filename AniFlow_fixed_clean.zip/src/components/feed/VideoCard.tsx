'use client';

import { cn, formatNumber } from '@/lib/utils';
import { useLanguage } from '@/i18n/LanguageProvider';
import { useHaptic } from '@/hooks/useHaptic';
import { useLibraryStore } from '@/store/libraryStore';
import { useUIStore } from '@/store/uiStore';
import { Badge } from '@/components/common/Badge';
import { Button } from '@/components/common/Button';
import { Heart, Bookmark, Share2, Play, Star, Lock } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import type { Anime } from '@/types/anime';

interface VideoCardProps {
  anime: Anime;
  className?: string;
}

export function VideoCard({ anime, className }: VideoCardProps) {
  const { t } = useLanguage();
  const { impact } = useHaptic();
  const { isFavorite, addFavorite, removeFavorite } = useLibraryStore();
  const { openPremiumModal } = useUIStore();
  const [isLiked, setIsLiked] = useState(anime.is_liked ?? false);
  const [likeCount, setLikeCount] = useState(anime.likes);

  const favorite = isFavorite(anime.id);

  const handleLike = () => {
    impact('light');
    setIsLiked((prev) => !prev);
    setLikeCount((prev) => (isLiked ? prev - 1 : prev + 1));
  };

  const handleFavorite = () => {
    impact('medium');
    if (favorite) {
      removeFavorite(anime.id);
    } else {
      addFavorite({
        animeId: anime.id,
        animeTitle: anime.title.en,
        coverUrl: anime.cover_url,
        addedAt: anime.created_at,
      });
    }
  };

  const handleShare = async () => {
    impact('medium');
    try {
      await navigator.share({
        title: anime.title.en,
        url: `${window.location.origin}/anime/${anime.id}`,
      });
    } catch {
      // User cancelled or share not supported
    }
  };

  const handleWatch = () => {
    if (anime.is_premium) {
      openPremiumModal(anime.id);
    }
  };

  return (
    <div className={cn('relative h-full w-full overflow-hidden bg-background', className)}>
      {/* Background image */}
      <Image
        src={anime.cover_url}
        alt={anime.title.en}
        fill
        className="object-cover"
        sizes="100vw"
        priority
      />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/90" />
      <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent" />

      {/* Top overlay - title */}
      <div className="absolute top-0 left-0 right-0 p-5 pt-[env(safe-area-inset-top)]">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2">
            {anime.is_premium && <Badge variant="premium">{t('home.premiumBadge')}</Badge>}
            <Badge variant="hot">
              <Star className="w-3 h-3 fill-current" />
              {anime.rating.toFixed(1)}
            </Badge>
          </div>
        </div>
      </div>

      {/* Bottom content */}
      <div className="absolute bottom-0 left-0 right-0 p-5 pb-[calc(env(safe-area-inset-bottom)+80px)]">
        <div className="flex items-end gap-4">
          {/* Text content */}
          <div className="flex-1 min-w-0">
            <h2 className="text-2xl font-display font-bold text-white mb-1 line-clamp-2">
              {anime.title.en}
            </h2>
            <p className="text-sm text-white/70 mb-2 line-clamp-2">{anime.description.en}</p>
            <div className="flex flex-wrap gap-1.5 mb-3">
              {anime.genres.slice(0, 3).map((genre) => (
                <span
                  key={genre}
                  className="px-2 py-0.5 text-[10px] font-medium rounded-full bg-white/10 backdrop-blur-sm text-white/80"
                >
                  {genre}
                </span>
              ))}
            </div>
            <Button
              variant={anime.is_premium ? 'premium' : 'primary'}
              size="sm"
              onClick={handleWatch}
              className="!px-6"
            >
              {anime.is_premium && <Lock className="w-3.5 h-3.5" />}
              <Play className="w-4 h-4 fill-current" />
              {t('anime.watchNow')}
            </Button>
          </div>

          {/* Action rail */}
          <div className="flex flex-col items-center gap-4">
            <button
              onClick={handleLike}
              className="flex flex-col items-center gap-1 text-white"
            >
              <div
                className={cn(
                  'p-2.5 rounded-full bg-white/10 backdrop-blur-sm transition-all',
                  isLiked && 'bg-error/30'
                )}
              >
                <Heart
                  className={cn('w-6 h-6', isLiked && 'fill-error text-error')}
                />
              </div>
              <span className="text-xs font-medium">{formatNumber(likeCount)}</span>
            </button>

            <button
              onClick={handleFavorite}
              className="flex flex-col items-center gap-1 text-white"
            >
              <div
                className={cn(
                  'p-2.5 rounded-full bg-white/10 backdrop-blur-sm transition-all',
                  favorite && 'bg-secondary/30'
                )}
              >
                <Bookmark
                  className={cn('w-6 h-6', favorite && 'fill-secondary text-secondary')}
                />
              </div>
              <span className="text-xs font-medium">{favorite ? 'Saved' : 'Save'}</span>
            </button>

            <button
              onClick={handleShare}
              className="flex flex-col items-center gap-1 text-white"
            >
              <div className="p-2.5 rounded-full bg-white/10 backdrop-blur-sm">
                <Share2 className="w-6 h-6" />
              </div>
              <span className="text-xs font-medium">Share</span>
            </button>
          </div>
        </div>
      </div>

      {/* Link to detail */}
      <Link
        href={`/anime/${anime.id}`}
        className="absolute inset-0 z-10"
        aria-label={anime.title.en}
      />
    </div>
  );
}
