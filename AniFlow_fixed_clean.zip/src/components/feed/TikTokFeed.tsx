'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useSwipe } from '@/hooks/useSwipe';
import { useHaptic } from '@/hooks/useHaptic';
import { VideoCard } from './VideoCard';
import type { Anime } from '@/types/anime';

interface TikTokFeedProps {
  items: Anime[];
  onEndReached?: () => void;
  hasMore?: boolean;
  isLoading?: boolean;
}

export function TikTokFeed({ items, onEndReached, hasMore = false, isLoading = false }: TikTokFeedProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const { impact } = useHaptic();

  const goToNext = useCallback(() => {
    if (currentIndex < items.length - 1) {
      setDirection(1);
      setCurrentIndex((prev) => prev + 1);
      impact('light');
    } else if (hasMore && onEndReached) {
      onEndReached();
    }
  }, [currentIndex, items.length, hasMore, onEndReached, impact]);

  const goToPrev = useCallback(() => {
    if (currentIndex > 0) {
      setDirection(-1);
      setCurrentIndex((prev) => prev - 1);
      impact('light');
    }
  }, [currentIndex, impact]);

  const swipeHandlers = useSwipe(
    {
      onSwipeUp: goToNext,
      onSwipeDown: goToPrev,
    },
    { threshold: 60, preventVerticalScroll: true }
  );

  // Keyboard navigation
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown') goToNext();
      if (e.key === 'ArrowUp') goToPrev();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [goToNext, goToPrev]);

  if (items.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-text-muted">
        No content available
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="relative h-full w-full overflow-hidden"
      {...swipeHandlers}
    >
      <AnimatePresence initial={false} custom={direction}>
        <motion.div
          key={items[currentIndex]?.id}
          custom={direction}
          initial={{ y: direction > 0 ? '100%' : '-100%', opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: direction > 0 ? '-100%' : '100%', opacity: 0 }}
          transition={{ type: 'spring', damping: 30, stiffness: 300 }}
          className="absolute inset-0"
        >
          <VideoCard anime={items[currentIndex]} />
        </motion.div>
      </AnimatePresence>

      {/* Progress indicator */}
      <div className="absolute right-3 top-1/2 -translate-y-1/2 z-20 flex flex-col gap-1.5">
        {items.map((item, idx) => (
          <div
            key={item.id}
            className={`w-1.5 rounded-full transition-all duration-300 ${
              idx === currentIndex
                ? 'h-6 bg-primary shadow-neon'
                : 'h-1.5 bg-white/30'
            }`}
          />
        ))}
      </div>

      {isLoading && (
        <div className="absolute bottom-20 left-1/2 -translate-x-1/2 z-20">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      )}
    </div>
  );
}
