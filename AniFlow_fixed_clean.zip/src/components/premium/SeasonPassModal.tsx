'use client';

import { Modal } from '@/components/common/Modal';
import { Button } from '@/components/common/Button';
import { Badge } from '@/components/common/Badge';
import { useLanguage } from '@/i18n/LanguageProvider';
import { useUIStore } from '@/store/uiStore';
import { useHaptic } from '@/hooks/useHaptic';
import { usePurchaseSeasonPass } from '@/features/premium/usePremium';
import { PREMIUM_PRICES } from '@/config/constants';
import { Check, Ticket, Star } from 'lucide-react';

interface SeasonPassModalProps {
  animeId: string;
  animeTitle?: string;
  isOpen: boolean;
  onClose: () => void;
}

export function SeasonPassModal({
  animeId,
  animeTitle,
  isOpen,
  onClose,
}: SeasonPassModalProps) {
  const { t } = useLanguage();
  const { showToast } = useUIStore();
  const { impact } = useHaptic();
  const purchaseSeasonPass = usePurchaseSeasonPass();

  const handlePurchase = async () => {
    impact('medium');
    try {
      const response = await purchaseSeasonPass.mutateAsync(animeId);
      if (response.invoice_url) {
        window.open(response.invoice_url, '_blank');
      }
      onClose();
    } catch {
      showToast(t('common.error'), 'error');
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={t('anime.unlockWithSeasonPass')}
    >
      <div className="space-y-6">
        {/* Anime title */}
        {animeTitle && (
          <div className="text-center">
            <h3 className="text-lg font-display font-semibold text-text-primary">
              {animeTitle}
            </h3>
          </div>
        )}

        {/* Pass details */}
        <div className="relative p-6 rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 via-surface2 to-secondary/10">
          <Badge variant="premium" className="absolute -top-2 right-4">
            <Ticket className="w-3 h-3" />
            Season Pass
          </Badge>

          <div className="flex items-center justify-center gap-4 py-4">
            <div className="text-center">
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-3xl font-display font-bold text-text-primary">
                  {PREMIUM_PRICES.seasonPass}
                </span>
                <Star className="w-4 h-4 text-warning fill-current" />
              </div>
              <p className="text-xs text-text-muted mt-1">One-time purchase</p>
            </div>
          </div>

          <div className="space-y-2">
            {[
              'Unlock all episodes of this anime',
              'No monthly subscription needed',
              'Support the creators directly',
            ].map((benefit) => (
              <div key={benefit} className="flex items-center gap-2">
                <Check className="w-4 h-4 text-success" />
                <span className="text-sm text-text-secondary">{benefit}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Purchase button */}
        <Button
          variant="premium"
          size="lg"
          fullWidth
          loading={purchaseSeasonPass.isLoading}
          disabled={!animeId}
          onClick={handlePurchase}
        >
          <Star className="w-4 h-4 fill-current" />
          {animeId ? t('premium.subscribe') : t('anime.lockedEpisodes')}
        </Button>
      </div>
    </Modal>
  );
}
