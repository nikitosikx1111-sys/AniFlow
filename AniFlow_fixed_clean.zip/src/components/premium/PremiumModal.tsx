'use client';

import { useState } from 'react';
import { Modal } from '@/components/common/Modal';
import { Button } from '@/components/common/Button';
import { Badge } from '@/components/common/Badge';
import { useLanguage } from '@/i18n/LanguageProvider';
import { useUIStore } from '@/store/uiStore';
import { useHaptic } from '@/hooks/useHaptic';
import { usePurchasePremium, usePremium } from '@/features/premium/usePremium';
import { PREMIUM_PRICES } from '@/config/constants';
import { Check, Crown, Sparkles, Star } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { PremiumPlan } from '@/types/premium';

const BENEFITS = [
  'premium.benefits.unlimited',
  'premium.benefits.exclusive',
  'premium.benefits.noAds',
  'premium.benefits.earlyAccess',
  'premium.benefits.hd',
  'premium.benefits.offline',
] as const;

export function PremiumModal() {
  const { t } = useLanguage();
  const { isPremiumModalOpen, closePremiumModal, showToast } = useUIStore();
  const { impact } = useHaptic();
  const { isPremium } = usePremium();
  const purchasePremium = usePurchasePremium();
  const [selectedPlan, setSelectedPlan] = useState<PremiumPlan>('monthly');

  const handleSubscribe = async () => {
    impact('medium');
    try {
      const response = await purchasePremium.mutateAsync(selectedPlan);
      if (response.invoice_url) {
        window.open(response.invoice_url, '_blank');
      }
      closePremiumModal();
    } catch {
      showToast(t('common.error'), 'error');
    }
  };

  return (
    <Modal
      isOpen={isPremiumModalOpen}
      onClose={closePremiumModal}
      title={t('premium.title')}
    >
      <div className="space-y-6">
        {/* Subtitle */}
        <p className="text-center text-text-secondary text-sm">
          {t('premium.subtitle')}
        </p>

        {/* Benefits */}
        <div className="space-y-3">
          {BENEFITS.map((benefit) => (
            <div key={benefit} className="flex items-center gap-3">
              <div className="p-1.5 rounded-full bg-success/15">
                <Check className="w-3.5 h-3.5 text-success" />
              </div>
              <span className="text-sm text-text-primary">{t(benefit)}</span>
            </div>
          ))}
        </div>

        {/* Plan selection */}
        <div className="grid grid-cols-2 gap-3">
          {(['monthly', 'yearly'] as const).map((plan) => (
            <button
              key={plan}
              onClick={() => {
                impact('light');
                setSelectedPlan(plan);
              }}
              className={cn(
                'relative p-4 rounded-2xl border text-left transition-all',
                selectedPlan === plan
                  ? 'border-primary bg-primary/10 shadow-neon'
                  : 'border-border bg-surface2/50 hover:border-primary/30'
              )}
            >
              {plan === 'yearly' && (
                <Badge variant="premium" className="absolute -top-2 right-2">
                  {t('premium.save')}
                </Badge>
              )}
              <div className="flex items-center gap-2 mb-2">
                {plan === 'yearly' ? (
                  <Crown className="w-4 h-4 text-accent" />
                ) : (
                  <Sparkles className="w-4 h-4 text-primary" />
                )}
                <span className="text-sm font-medium text-text-primary">
                  {t(`premium.${plan}`)}
                </span>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-display font-bold text-text-primary">
                  {PREMIUM_PRICES[plan]}
                </span>
                <span className="text-xs text-text-muted">★</span>
              </div>
              <span className="text-xs text-text-muted">
                {t('premium.perMonth')}
              </span>
            </button>
          ))}
        </div>

        {/* Subscribe button */}
        <Button
          variant="premium"
          size="lg"
          fullWidth
          loading={purchasePremium.isLoading}
          onClick={handleSubscribe}
        >
          <Star className="w-4 h-4 fill-current" />
          {t('premium.subscribe')}
        </Button>

        {isPremium && (
          <p className="text-center text-xs text-success">
            {t('premium.currentPlan')}
          </p>
        )}
      </div>
    </Modal>
  );
}
