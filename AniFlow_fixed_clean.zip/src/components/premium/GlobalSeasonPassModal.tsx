'use client';

import { useUIStore } from '@/store/uiStore';
import { SeasonPassModal } from './SeasonPassModal';

export function GlobalSeasonPassModal() {
  const { isSeasonPassModalOpen, seasonPassModalAnimeId, closeSeasonPassModal } =
    useUIStore();

  if (!isSeasonPassModalOpen) return null;

  return (
    <SeasonPassModal
      animeId={seasonPassModalAnimeId ?? ''}
      isOpen={isSeasonPassModalOpen}
      onClose={closeSeasonPassModal}
    />
  );
}
