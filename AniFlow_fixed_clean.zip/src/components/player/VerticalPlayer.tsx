'use client';

import { useRef, useState, useCallback, useEffect, useMemo } from 'react';
import { usePlayerStore } from '@/store/playerStore';
import { useHaptic } from '@/hooks/useHaptic';
import { PlayerControls } from './PlayerControls';
import { PremiumOverlay } from './PremiumOverlay';
import { Play } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Episode } from '@/types/episode';

interface VerticalPlayerProps {
  episode: Episode;
  hasAccess?: boolean;
  onProgress?: (progress: number) => void;
  onEnded?: () => void;
}

export function VerticalPlayer({ episode, hasAccess = true, onProgress, onEnded }: VerticalPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [showControls, setShowControls] = useState(true);
  const [isBuffering, setIsBuffering] = useState(false);
  const sources = useMemo(
    () =>
      episode.video_sources?.length
        ? episode.video_sources
        : [{ label: 'Auto', quality: 'auto' as const, url: episode.video_url }],
    [episode.video_sources, episode.video_url]
  );
  const [selectedQuality, setSelectedQuality] = useState(sources[0]?.label ?? 'Auto');
  const controlsTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const { impact } = useHaptic();

  const {
    isPlaying,
    currentTime,
    duration,
    playbackRate,
    isMuted,
    isFullscreen,
    setPlaying,
    setCurrentTime,
    setPlaybackRate,
    setMuted,
    setFullscreen,
  } = usePlayerStore();

  const togglePlay = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    if (video.paused) {
      video.play();
      setPlaying(true);
    } else {
      video.pause();
      setPlaying(false);
    }
    impact('light');
  }, [setPlaying, impact]);

  const handleTimeUpdate = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    setCurrentTime(video.currentTime, video.duration);
    onProgress?.(video.currentTime / video.duration);
  }, [setCurrentTime, onProgress]);

  const handleLoadedMetadata = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    const savedProgress = episode.progress ?? 0;
    const normalizedProgress = savedProgress > 1 ? savedProgress / 100 : savedProgress;
    if (normalizedProgress > 0 && normalizedProgress < 0.95) {
      video.currentTime = normalizedProgress * video.duration;
    }
    setCurrentTime(video.currentTime, video.duration);
  }, [episode.progress, setCurrentTime]);

  const handleSeek = useCallback(
    (time: number) => {
      const video = videoRef.current;
      if (!video) return;
      video.currentTime = time;
      setCurrentTime(time, video.duration);
    },
    [setCurrentTime]
  );

  const handleSpeedChange = useCallback(
    (rate: number) => {
      const video = videoRef.current;
      if (video) {
        video.playbackRate = rate;
      }
      setPlaybackRate(rate);
    },
    [setPlaybackRate]
  );

  const handleMuteToggle = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    setMuted(video.muted);
  }, [setMuted]);

  const handleFullscreenToggle = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    if (!document.fullscreenElement) {
      video.requestFullscreen();
      setFullscreen(true);
    } else {
      document.exitFullscreen();
      setFullscreen(false);
    }
  }, [setFullscreen]);

  const handleQualityChange = useCallback(
    (quality: string) => {
      const video = videoRef.current;
      const source = sources.find((item) => item.label === quality);
      if (!video || !source) return;

      const wasPlaying = !video.paused;
      const time = video.currentTime;
      setSelectedQuality(source.label);
      video.src = source.url;
      video.currentTime = time;
      if (wasPlaying) {
        video.play().catch(() => setPlaying(false));
      }
    },
    [setPlaying, sources]
  );

  const handleVideoClick = useCallback(() => {
    setShowControls((prev) => !prev);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    if (!showControls) {
      controlsTimeoutRef.current = setTimeout(() => setShowControls(false), 3000);
    }
  }, [showControls]);

  useEffect(() => {
    if (showControls) {
      controlsTimeoutRef.current = setTimeout(() => setShowControls(false), 3000);
    }
    return () => {
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
    };
  }, [showControls]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleWaiting = () => setIsBuffering(true);
    const handleCanPlay = () => setIsBuffering(false);
    const handleEnded = () => {
      setPlaying(false);
      onEnded?.();
    };

    video.addEventListener('waiting', handleWaiting);
    video.addEventListener('canplay', handleCanPlay);
    video.addEventListener('ended', handleEnded);

    return () => {
      video.removeEventListener('waiting', handleWaiting);
      video.removeEventListener('canplay', handleCanPlay);
      video.removeEventListener('ended', handleEnded);
    };
  }, [onEnded, setPlaying]);

  if (!hasAccess) {
    return <PremiumOverlay episode={episode} />;
  }

  return (
    <div
      className={cn(
        'relative w-full bg-black overflow-hidden',
        isFullscreen ? 'h-screen' : 'aspect-video'
      )}
      onClick={handleVideoClick}
    >
      <video
        ref={videoRef}
        src={sources.find((item) => item.label === selectedQuality)?.url ?? episode.video_url}
        poster={episode.thumbnail_url}
        className="w-full h-full object-contain"
        playsInline
        preload="metadata"
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
      />

      {/* Buffering indicator */}
      {isBuffering && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      )}

      {/* Center play/pause button */}
      {!isPlaying && !isBuffering && (
        <div className="absolute inset-0 flex items-center justify-center">
          <button
            onClick={(e) => {
              e.stopPropagation();
              togglePlay();
            }}
            className="p-5 rounded-full bg-black/50 backdrop-blur-sm border border-white/20"
          >
            <Play className="w-10 h-10 text-white fill-current" />
          </button>
        </div>
      )}

      {/* Controls overlay */}
      <div
        className={cn(
          'absolute inset-0 transition-opacity duration-300',
          showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'
        )}
      >
        <PlayerControls
          isPlaying={isPlaying}
          currentTime={currentTime}
          duration={duration}
          playbackRate={playbackRate}
          isMuted={isMuted}
          isFullscreen={isFullscreen}
          onPlayPause={togglePlay}
          onSeek={handleSeek}
          onSpeedChange={handleSpeedChange}
          onMuteToggle={handleMuteToggle}
          onFullscreenToggle={handleFullscreenToggle}
          qualityOptions={sources.map((source) => source.label)}
          selectedQuality={selectedQuality}
          onQualityChange={handleQualityChange}
        />
      </div>
    </div>
  );
}
