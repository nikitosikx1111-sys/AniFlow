'use client';

import { formatDuration } from '@/lib/utils';
import { useLanguage } from '@/i18n/LanguageProvider';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  Gauge,
  Settings2,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useRef, useState, type ChangeEvent } from 'react';

interface PlayerControlsProps {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  playbackRate: number;
  isMuted: boolean;
  isFullscreen: boolean;
  onPlayPause: () => void;
  onSeek: (time: number) => void;
  onSpeedChange: (rate: number) => void;
  onMuteToggle: () => void;
  onFullscreenToggle: () => void;
  qualityOptions?: string[];
  selectedQuality?: string;
  onQualityChange?: (quality: string) => void;
}

const SPEED_OPTIONS = [0.5, 0.75, 1, 1.25, 1.5, 2];

export function PlayerControls({
  isPlaying,
  currentTime,
  duration,
  playbackRate,
  isMuted,
  isFullscreen,
  onPlayPause,
  onSeek,
  onSpeedChange,
  onMuteToggle,
  onFullscreenToggle,
  qualityOptions = [],
  selectedQuality,
  onQualityChange,
}: PlayerControlsProps) {
  const { t } = useLanguage();
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const progressRef = useRef<HTMLInputElement>(null);

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  const handleProgressChange = (e: ChangeEvent<HTMLInputElement>) => {
    const value = Number(e.target.value);
    const time = (value / 100) * duration;
    onSeek(time);
  };

  return (
    <div className="absolute inset-0 flex flex-col justify-between bg-gradient-to-b from-black/60 via-transparent to-black/80 p-4">
      {/* Top bar */}
      <div className="flex items-center justify-between">
        <span className="text-white text-sm font-medium">
          {formatDuration(currentTime)} / {formatDuration(duration)}
        </span>
        <span className="text-white/80 text-xs">{t('player.autoPlay')}</span>
      </div>

      {/* Center controls */}
      <div className="flex items-center justify-center gap-6">
        <button
          onClick={onPlayPause}
          className="p-4 rounded-full bg-white/10 backdrop-blur-sm hover:bg-white/20 transition-colors"
        >
          {isPlaying ? (
            <Pause className="w-8 h-8 text-white fill-current" />
          ) : (
            <Play className="w-8 h-8 text-white fill-current" />
          )}
        </button>
      </div>

      {/* Bottom controls */}
      <div className="space-y-3">
        {/* Progress bar */}
        <div className="flex items-center gap-3">
          <input
            ref={progressRef}
            type="range"
            min={0}
            max={100}
            value={progress}
            onChange={handleProgressChange}
            className="w-full h-1.5 bg-white/20 rounded-full appearance-none cursor-pointer accent-primary"
            style={{
              background: `linear-gradient(to right, #a855f7 ${progress}%, rgba(255,255,255,0.2) ${progress}%)`,
            }}
          />
          <span className="text-white/80 text-xs w-12 text-right">
            {formatDuration(duration - currentTime)}
          </span>
        </div>

        {/* Control buttons */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onMuteToggle}
              className="p-2 rounded-lg hover:bg-white/10 transition-colors"
            >
              {isMuted ? (
                <VolumeX className="w-5 h-5 text-white" />
              ) : (
                <Volume2 className="w-5 h-5 text-white" />
              )}
            </button>

            <div className="relative">
              <button
                onClick={() => setShowSpeedMenu((prev) => !prev)}
                className={cn(
                  'flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-white/10 transition-colors',
                  showSpeedMenu && 'bg-white/10'
                )}
              >
                <Gauge className="w-4 h-4 text-white" />
                <span className="text-white text-xs font-medium">{playbackRate}x</span>
              </button>

              {showSpeedMenu && (
                <div className="absolute bottom-full left-0 mb-2 bg-surface border border-border rounded-xl shadow-neon overflow-hidden">
                  {SPEED_OPTIONS.map((speed) => (
                    <button
                      key={speed}
                      onClick={() => {
                        onSpeedChange(speed);
                        setShowSpeedMenu(false);
                      }}
                      className={cn(
                        'block w-full px-4 py-2 text-sm text-left hover:bg-surface2 transition-colors',
                        speed === playbackRate
                          ? 'text-primary font-medium'
                          : 'text-text-secondary'
                      )}
                    >
                      {speed}x
                    </button>
                  ))}
                </div>
              )}
            </div>

            {qualityOptions.length > 1 && (
              <div className="relative">
                <button
                  onClick={() => setShowQualityMenu((prev) => !prev)}
                  className={cn(
                    'flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-white/10 transition-colors',
                    showQualityMenu && 'bg-white/10'
                  )}
                >
                  <Settings2 className="w-4 h-4 text-white" />
                  <span className="text-white text-xs font-medium">
                    {selectedQuality ?? 'Auto'}
                  </span>
                </button>

                {showQualityMenu && (
                  <div className="absolute bottom-full left-0 mb-2 bg-surface border border-border rounded-xl shadow-neon overflow-hidden">
                    {qualityOptions.map((quality) => (
                      <button
                        key={quality}
                        onClick={() => {
                          onQualityChange?.(quality);
                          setShowQualityMenu(false);
                        }}
                        className={cn(
                          'block w-full px-4 py-2 text-sm text-left hover:bg-surface2 transition-colors',
                          quality === selectedQuality
                            ? 'text-primary font-medium'
                            : 'text-text-secondary'
                        )}
                      >
                        {quality}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          <button
            onClick={onFullscreenToggle}
            className="p-2 rounded-lg hover:bg-white/10 transition-colors"
          >
            {isFullscreen ? (
              <Minimize className="w-5 h-5 text-white" />
            ) : (
              <Maximize className="w-5 h-5 text-white" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
