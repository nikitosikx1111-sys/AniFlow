'use client';

import { useLanguage } from '@/i18n/LanguageProvider';
import { useUIStore } from '@/store/uiStore';
import { Button } from '@/components/common/Button';
import { Badge } from '@/components/common/Badge';
import { Lock, Crown, Sparkles } from 'lucide-react';
import Image from 'next/image';
import type { Episode } from '@/types/episode';

interface PremiumOverlayProps {
  episode: Episode;
}

export function PremiumOverlay({ episode }: PremiumOverlayProps) {
  const { t } = useLanguage();
  const { openPremiumModal } = useUIStore();

  return (
    <div className="relative w-full aspect-video overflow-hidden bg-background">
      <Image
        src={episode.thumbnail_url}
        alt={episode.title.en}
        fill
        className="object-cover blur-md scale-110"
        sizes="100vw"
      />
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div className="absolute inset-0 bg-gradient-to-t from-primary/30 via-transparent to-transparent" />

      <div className="relative z-10 h-full flex flex-col items-center justify-center p-6 text-center">
        <div className="mb-4">
          <Badge variant="premium" className="!px-4 !py-1.5 !text-xs">
            <Crown className="w-4 h-4" />
            {t('player.episodeLocked')}
          </Badge>
        </div>

        <h3 className="text-xl font-display font-bold text-white mb-2">
          {episode.title.en}
        </h3>
        <p className="text-sm text-white/70 mb-6 max-w-sm">
          {t('player.premiumRequired')}
        </p>

        <div className="flex flex-col gap-3 w-full max-w-xs">
          <Button
            variant="premium"
            size="lg"
            fullWidth
            onClick={() => openPremiumModal(episode.anime_id)}
          >
            <Sparkles className="w-4 h-4" />
            {t('player.getPremium')}
          </Button>
          <Button variant="outline" size="lg" fullWidth>
            <Lock className="w-4 h-4" />
            {t('player.getSeasonPass')}
          </Button>
        </div>
      </div>
    </div>
  );
}
