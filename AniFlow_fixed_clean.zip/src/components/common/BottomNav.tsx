'use client';

import { cn } from '@/lib/utils';
import { useLanguage } from '@/i18n/LanguageProvider';
import { useUIStore } from '@/store/uiStore';
import { useHaptic } from '@/hooks/useHaptic';
import { Home, Compass, Library, User } from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion } from 'framer-motion';
import type { AppRoute, TabKey } from '@/types/navigation';

const navItems: { key: TabKey; icon: typeof Home; activeIcon: typeof Home; route: AppRoute; labelKey: string }[] = [
  { key: 'home', icon: Home, activeIcon: Home, route: '/', labelKey: 'nav.home' },
  { key: 'explore', icon: Compass, activeIcon: Compass, route: '/explore', labelKey: 'nav.explore' },
  { key: 'library', icon: Library, activeIcon: Library, route: '/library', labelKey: 'nav.library' },
  { key: 'profile', icon: User, activeIcon: User, route: '/profile', labelKey: 'nav.profile' },
];

export function BottomNav() {
  const pathname = usePathname();
  const { t } = useLanguage();
  const { isBottomNavVisible } = useUIStore();
  const { impact } = useHaptic();

  if (!isBottomNavVisible) return null;

  const isActive = (route: AppRoute) => {
    if (route === '/') return pathname === '/';
    return pathname.startsWith(route);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 pb-[env(safe-area-inset-bottom)]">
      <div className="mx-auto max-w-lg px-4 pb-3">
        <div className="flex items-center justify-around bg-surface/80 backdrop-blur-2xl border border-border/50 rounded-3xl shadow-neon px-2 py-2">
          {navItems.map((item) => {
            const active = isActive(item.route);
            const Icon = active ? item.activeIcon : item.icon;
            return (
              <Link
                key={item.key}
                href={item.route}
                onClick={() => impact('light')}
                className={cn(
                  'relative flex flex-col items-center gap-0.5 px-4 py-1.5 rounded-2xl transition-colors',
                  active ? 'text-primary' : 'text-text-muted hover:text-text-secondary'
                )}
              >
                {active && (
                  <motion.div
                    layoutId="bottom-nav-active"
                    className="absolute inset-0 bg-primary/10 rounded-2xl"
                    transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                  />
                )}
                <Icon className="relative w-5 h-5" strokeWidth={active ? 2.5 : 2} />
                <span className="relative text-[10px] font-medium">{t(item.labelKey)}</span>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
