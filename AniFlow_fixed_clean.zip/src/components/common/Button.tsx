'use client';

import { cn } from '@/lib/utils';
import { useHaptic } from '@/hooks/useHaptic';
import { Loader2 } from 'lucide-react';
import { forwardRef, type ButtonHTMLAttributes, type MouseEvent } from 'react';

type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'outline' | 'danger' | 'premium';
type ButtonSize = 'xs' | 'sm' | 'md' | 'lg' | 'icon';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  isLoading?: boolean;
  loading?: boolean;
  fullWidth?: boolean;
  hapticFeedback?: boolean;
}

const variantClasses: Record<ButtonVariant, string> = {
  primary:
    'bg-primary text-white hover:bg-primary-light shadow-neon hover:shadow-neon-strong',
  secondary:
    'bg-secondary text-white hover:bg-secondary-light shadow-[0_0_20px_rgba(6,182,212,0.3)]',
  ghost: 'bg-transparent text-text-secondary hover:bg-surface2 hover:text-text-primary',
  outline:
    'border border-border bg-transparent text-text-primary hover:border-primary/50 hover:text-primary',
  danger: 'bg-error text-white hover:bg-error/90',
  premium:
    'bg-gradient-to-r from-accent via-primary to-secondary text-white shadow-neon hover:shadow-neon-strong',
};

const sizeClasses: Record<ButtonSize, string> = {
  xs: 'px-2.5 py-1.5 text-xs rounded-lg',
  sm: 'px-3 py-2 text-sm rounded-xl',
  md: 'px-4 py-2.5 text-sm rounded-xl',
  lg: 'px-6 py-3.5 text-base rounded-2xl',
  icon: 'p-2.5 rounded-xl',
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant = 'primary',
      size = 'md',
      isLoading = false,
      loading = false,
      fullWidth = false,
      hapticFeedback = true,
      disabled,
      children,
      onClick,
      ...props
    },
    ref
  ) => {
    const { impact } = useHaptic();

    const handleClick = (e: MouseEvent<HTMLButtonElement>) => {
      const pending = isLoading || loading;
      if (hapticFeedback && !disabled && !pending) {
        impact('light');
      }
      onClick?.(e);
    };

    return (
      <button
        ref={ref}
        className={cn(
          'relative inline-flex items-center justify-center gap-2 font-medium',
          'transition-all duration-200 active:scale-[0.97]',
          'focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50',
          'disabled:opacity-50 disabled:pointer-events-none',
          variantClasses[variant],
          sizeClasses[size],
          fullWidth && 'w-full',
          className
        )}
        disabled={disabled || isLoading || loading}
        onClick={handleClick}
        {...props}
      >
        {(isLoading || loading) && <Loader2 className="w-4 h-4 animate-spin" />}
        {children}
      </button>
    );
  }
);

Button.displayName = 'Button';
