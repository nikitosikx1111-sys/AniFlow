'use client';

import { cn } from '@/lib/utils';
import { type HTMLAttributes } from 'react';

type BadgeVariant = 'premium' | 'free' | 'episode' | 'new' | 'hot' | 'default';

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  variant?: BadgeVariant;
}

const variantClasses: Record<BadgeVariant, string> = {
  premium:
    'bg-gradient-to-r from-accent via-primary to-secondary text-white shadow-neon',
  free: 'bg-success/20 text-success border border-success/30',
  episode: 'bg-surface2 text-text-secondary border border-border',
  new: 'bg-secondary/20 text-secondary-light border border-secondary/30',
  hot: 'bg-error/20 text-error border border-error/30',
  default: 'bg-surface2 text-text-secondary border border-border',
};

export function Badge({ className, variant = 'default', children, ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider rounded-full',
        variantClasses[variant],
        className
      )}
      {...props}
    >
      {children}
    </span>
  );
}
