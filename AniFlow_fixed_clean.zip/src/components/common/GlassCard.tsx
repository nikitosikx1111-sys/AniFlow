'use client';

import { cn } from '@/lib/utils';
import { forwardRef, type HTMLAttributes } from 'react';

interface GlassCardProps extends HTMLAttributes<HTMLDivElement> {
  hover?: boolean;
  glow?: boolean;
  padded?: boolean;
}

export const GlassCard = forwardRef<HTMLDivElement, GlassCardProps>(
  ({ className, hover = false, glow = false, padded = true, children, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          'relative rounded-2xl border border-border/50 bg-surface/60 backdrop-blur-xl',
          'shadow-glass',
          padded && 'p-4',
          glow && 'shadow-glass-light',
          hover &&
            'transition-all duration-300 hover:border-primary/40 hover:shadow-neon hover:-translate-y-0.5',
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

GlassCard.displayName = 'GlassCard';
