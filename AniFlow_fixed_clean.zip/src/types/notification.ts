export type NotificationType = 'premium_activated' | 'new_episode' | 'discount' | 'referral_reward';

export interface AppNotification {
  id: string;
  user_id: string;
  type: NotificationType;
  title: {
    en: string;
    uk: string;
    ru: string;
  };
  body: {
    en: string;
    uk: string;
    ru: string;
  };
  data?: Record<string, unknown>;
  is_read: boolean;
  created_at: string;
}

export interface NotificationPreference {
  premium_activated: boolean;
  new_episode: boolean;
  discount: boolean;
  referral_reward: boolean;
}
