export type TabKey = 'home' | 'explore' | 'library' | 'profile';
export type AppRoute = '/' | '/explore' | '/library' | '/profile' | '/premium' | '/settings' | '/admin';

export interface TabItem {
  key: TabKey;
  label: string;
  icon: string;
  route: AppRoute;
}

export interface NavigationItem {
  key: TabKey;
  labelKey: string;
  icon: string;
  activeIcon: string;
  route: AppRoute;
}
