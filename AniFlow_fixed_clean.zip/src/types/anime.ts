export interface LocalizedText {
  en: string;
  uk: string;
  ru: string;
}

export type AnimeStatus = 'ongoing' | 'completed';

export interface Anime {
  id: string;
  title: LocalizedText;
  description: LocalizedText;
  cover_url: string;
  banner_url: string;
  trailer_url?: string;
  studio: string;
  genres: string[];
  status: AnimeStatus;
  rating: number;
  views: number;
  likes: number;
  is_premium: boolean;
  is_liked?: boolean;
  is_favorite?: boolean;
  created_at: string;
}

export interface Season {
  id: string;
  anime_id: string;
  number: number;
  title: LocalizedText;
  episode_count: number;
}

export interface Episode {
  id: string;
  season_id: string;
  anime_id: string;
  number: number;
  title: LocalizedText;
  video_url: string;
  video_sources?: {
    label: string;
    quality: '360p' | '480p' | '720p' | '1080p' | 'auto';
    url: string;
    mime_type?: string;
  }[];
  thumbnail_url: string;
  preview_url?: string;
  duration: number;
  is_free: boolean;
  views: number;
  likes: number;
  is_liked?: boolean;
  progress?: number;
  scheduled_at?: string;
}

export interface AnimeDetail extends Anime {
  seasons: Season[];
  episodes: Episode[];
  recommendations: Anime[];
}

export interface AnimeListParams {
  page?: number;
  limit?: number;
  genre?: string;
  status?: AnimeStatus;
  sort?: 'popular' | 'new' | 'top_rated' | 'completed' | 'ongoing';
  search?: string;
}

export interface AnimeListResponse {
  items: Anime[];
  page: number;
  limit: number;
  total: number;
  hasMore: boolean;
}

export interface WatchProgress {
  anime_id: string;
  episode_id: string;
  progress: number;
  last_watched_at: string;
}

export interface ContinueWatchingItem {
  anime: Anime;
  episode: Episode;
  progress: number;
  last_watched_at: string;
}
