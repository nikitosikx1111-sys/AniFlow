export interface ReferralInfo {
  code: string;
  referral_link: string;
  referral_count: number;
  reward_progress: number;
  total_earned: number;
  next_reward_at: number;
}

export interface ReferralHistoryItem {
  id: string;
  referred_user_name: string;
  reward: number;
  status: 'pending' | 'rewarded';
  created_at: string;
}

export interface ReferralReward {
  id: string;
  reward: number;
  status: 'pending' | 'rewarded';
  created_at: string;
}
