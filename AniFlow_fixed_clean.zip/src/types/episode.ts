import type { LocalizedText } from './anime';

export interface Episode {
  id: string;
  season_id: string;
  anime_id: string;
  number: number;
  title: LocalizedText;
  video_url: string;
  video_sources?: VideoSource[];
  thumbnail_url: string;
  preview_url?: string;
  duration: number;
  is_free: boolean;
  views: number;
  likes: number;
  is_liked?: boolean;
  progress?: number;
  scheduled_at?: string;
}

export interface VideoSource {
  label: string;
  quality: '360p' | '480p' | '720p' | '1080p' | 'auto';
  url: string;
  mime_type?: string;
}

export interface EpisodeDetail extends Episode {
  anime_title: LocalizedText;
  anime_cover_url: string;
  next_episode?: Episode;
  has_access: boolean;
}

export interface PlayerState {
  is_playing: boolean;
  current_time: number;
  duration: number;
  playback_rate: number;
  is_muted: boolean;
  is_fullscreen: boolean;
  progress: number;
}
