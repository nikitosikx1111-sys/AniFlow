export type Language = 'en' | 'uk' | 'ru';

export interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  is_premium?: boolean;
  photo_url?: string;
}

export interface User {
  id: string;
  telegram_id: number;
  username: string;
  first_name: string;
  last_name?: string;
  avatar_url?: string;
  language: Language;
  is_premium: boolean;
  premium_expires_at?: string;
  is_admin: boolean;
  referral_code: string;
  referred_by?: string;
  referral_count: number;
  created_at: string;
  updated_at: string;
}

export interface AuthResponse {
  user: User;
  token: string;
}
