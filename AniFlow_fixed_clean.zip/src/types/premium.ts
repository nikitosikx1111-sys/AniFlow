export type PremiumPlan = 'monthly' | 'yearly';

export interface PremiumSubscription {
  id: string;
  user_id: string;
  plan: PremiumPlan;
  status: 'active' | 'expired' | 'cancelled';
  started_at: string;
  expires_at: string;
  telegram_payment_id?: string;
}

export interface SeasonPass {
  id: string;
  user_id: string;
  anime_id: string;
  status: 'active' | 'expired';
  purchased_at: string;
  expires_at?: string;
  telegram_payment_id?: string;
}

export interface PremiumStatus {
  is_premium: boolean;
  subscription?: PremiumSubscription;
  season_passes: SeasonPass[];
  expires_at?: string;
}

export interface CheckoutResponse {
  invoice_url: string;
  invoice_id: string;
}

export interface PaymentHistoryItem {
  id: string;
  type: 'premium' | 'season_pass';
  status: 'pending' | 'paid' | 'failed' | 'refunded';
  amount_stars: number;
  plan?: PremiumPlan;
  anime_id?: string;
  telegram_payment_id?: string;
  created_at: string;
  paid_at?: string;
}
