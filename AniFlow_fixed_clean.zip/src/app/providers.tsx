'use client';

import { useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import { QueryClientProvider } from 'react-query';
import { queryClient } from '@/lib/query-client';
import { LanguageProvider } from '@/i18n/LanguageProvider';
import { BottomNav } from '@/components/common/BottomNav';
import { PremiumModal } from '@/components/premium/PremiumModal';
import { GlobalSeasonPassModal } from '@/components/premium/GlobalSeasonPassModal';
import { authService } from '@/services/auth.service';
import { useTelegram } from '@/hooks/useTelegram';
import { useUserStore } from '@/store/userStore';

function TelegramAuthBootstrap() {
  const { initData, isReady } = useTelegram();
  const { token, user, setToken, setUser } = useUserStore();

  useEffect(() => {
    if (!isReady || token || user || !initData) return;

    let cancelled = false;
    authService
      .authenticate(initData)
      .then((data) => {
        if (cancelled) return;
        setToken(data.token);
        setUser(data.user);
      })
      .catch(() => {
        // Public catalogue pages should still render when auth is unavailable.
      });

    return () => {
      cancelled = true;
    };
  }, [initData, isReady, setToken, setUser, token, user]);

  return null;
}

export function Providers({ children }: { children: ReactNode }) {
  const [clientReady, setClientReady] = useState(false);

  useEffect(() => {
    setClientReady(true);
  }, []);

  if (!clientReady) {
    return <div className="min-h-screen bg-background" />;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <TelegramAuthBootstrap />
        <div className="min-h-screen pb-20">{children}</div>
        <BottomNav />
        <PremiumModal />
        <GlobalSeasonPassModal />
      </LanguageProvider>
    </QueryClientProvider>
  );
}
