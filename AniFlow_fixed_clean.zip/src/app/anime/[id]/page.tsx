'use client';

import { useMemo, useState } from 'react';
import { useParams } from 'next/navigation';
import { useQuery } from 'react-query';
import { animeService } from '@/services/anime.service';
import { useLanguage } from '@/i18n/LanguageProvider';
import { useLibraryStore } from '@/store/libraryStore';
import { useUIStore } from '@/store/uiStore';
import { useHaptic } from '@/hooks/useHaptic';
import { GlassCard } from '@/components/common/GlassCard';
import { Badge } from '@/components/common/Badge';
import { Button } from '@/components/common/Button';
import { EpisodeList } from '@/components/anime/EpisodeList';
import { AnimeGrid } from '@/components/anime/AnimeGrid';
import { Skeleton } from '@/components/common/Skeleton';
import {
  Play,
  Heart,
  Bookmark,
  Share2,
  Star,
  Eye,
  Clock,
  Crown,
  ChevronDown,
} from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { cn, formatNumber } from '@/lib/utils';
import type { AnimeDetail, Season } from '@/types/anime';

export default function AnimeDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { t } = useLanguage();
  const { impact } = useHaptic();
  const { isFavorite, addFavorite, removeFavorite, addHistory } = useLibraryStore();
  const { openPremiumModal } = useUIStore();
  const [isLiked, setIsLiked] = useState(false);
  const [selectedSeason, setSelectedSeason] = useState<string | null>(null);
  const [showAllEpisodes, setShowAllEpisodes] = useState(false);

  const { data: anime, isLoading, isError } = useQuery(
    ['anime', 'detail', id],
    () => animeService.getAnimeDetail(id),
    { staleTime: 5 * 60 * 1000 }
  );

  const favorite = anime ? isFavorite(anime.id) : false;

  const seasons = useMemo<Season[]>(() => {
    if (!anime || !('seasons' in anime)) return [];
    return (anime as AnimeDetail).seasons ?? [];
  }, [anime]);

  const episodes = useMemo(() => {
    if (!anime || !('episodes' in anime)) return [];
    return (anime as AnimeDetail).episodes ?? [];
  }, [anime]);

  const recommendations = useMemo(() => {
    if (!anime || !('recommendations' in anime)) return [];
    return (anime as AnimeDetail).recommendations ?? [];
  }, [anime]);

  const handleFavorite = () => {
    if (!anime) return;
    impact('medium');
    if (favorite) {
      removeFavorite(anime.id);
    } else {
      addFavorite({
        animeId: anime.id,
        animeTitle: anime.title.en,
        coverUrl: anime.cover_url,
        addedAt: new Date().toISOString(),
      });
    }
  };

  const handleLike = () => {
    impact('light');
    setIsLiked((prev) => !prev);
  };

  const handleShare = async () => {
    if (!anime) return;
    impact('medium');
    try {
      await navigator.share({
        title: anime.title.en,
        url: window.location.href,
      });
    } catch {
      // User cancelled
    }
  };

  const handleWatch = () => {
    if (!anime) return;
    impact('medium');

    if (anime.is_premium) {
      openPremiumModal(anime.id);
      return;
    }

    const firstEpisode = episodes[0];
    if (firstEpisode) {
      addHistory({
        animeId: anime.id,
        animeTitle: anime.title.en,
        coverUrl: anime.cover_url,
        episodeId: firstEpisode.id,
        episodeTitle: firstEpisode.title.en,
        progress: 0,
        watchedAt: new Date().toISOString(),
      });
      window.location.href = `/watch/${firstEpisode.id}`;
    }
  };

  if (isLoading) {
    return (
      <main className="min-h-screen bg-background safe-top">
        <div className="relative h-80 bg-surface">
          <Skeleton className="w-full h-full" />
        </div>
        <div className="px-4 py-6 space-y-4">
          <Skeleton variant="text" className="w-2/3 h-8" />
          <Skeleton variant="text" className="w-full" />
          <Skeleton variant="text" className="w-3/4" />
          <div className="grid grid-cols-3 gap-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="aspect-[2/3]" />
            ))}
          </div>
        </div>
      </main>
    );
  }

  if (isError || !anime) {
    return (
      <main className="min-h-screen bg-background safe-top flex flex-col items-center justify-center gap-4 px-4">
        <p className="text-text-muted">{t('common.error')}</p>
        <Link
          href="/explore"
          className="px-6 py-2 rounded-full bg-primary text-white text-sm font-medium"
        >
          {t('common.back')}
        </Link>
      </main>
    );
  }

  const visibleEpisodes = showAllEpisodes ? episodes : episodes.slice(0, 3);

  return (
    <main className="min-h-screen bg-background safe-top">
      {/* Banner */}
      <div className="relative h-80 overflow-hidden">
        <Image
          src={anime.banner_url || anime.cover_url}
          alt={anime.title.en}
          fill
          className="object-cover"
          sizes="100vw"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />

        {/* Back button */}
        <Link
          href="/explore"
          className="absolute top-4 left-4 p-2.5 rounded-full bg-black/40 backdrop-blur-sm border border-white/20"
        >
          <ChevronDown className="w-5 h-5 text-white rotate-90" />
        </Link>

        {/* Top badges */}
        <div className="absolute top-4 right-4 flex items-center gap-2">
          {anime.is_premium && <Badge variant="premium">{t('home.premiumBadge')}</Badge>}
          <Badge variant="hot">
            <Star className="w-3 h-3 fill-current" />
            {anime.rating.toFixed(1)}
          </Badge>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-6 space-y-6 -mt-16 relative z-10">
        {/* Title & actions */}
        <div>
          <h1 className="text-2xl font-display font-bold text-white mb-2">
            {anime.title.en}
          </h1>
          <div className="flex items-center gap-3 text-xs text-text-secondary mb-4">
            <span className="flex items-center gap-1">
              <Eye className="w-3.5 h-3.5" />
              {formatNumber(anime.views)}
            </span>
            <span className="flex items-center gap-1">
              <Heart className={cn('w-3.5 h-3.5', isLiked && 'fill-error text-error')} />
              {formatNumber(anime.likes)}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              {anime.status}
            </span>
          </div>

          <div className="flex flex-wrap gap-1.5 mb-4">
            {anime.genres.map((genre) => (
              <Badge key={genre} variant="default">
                {genre}
              </Badge>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <Button
              variant={anime.is_premium ? 'premium' : 'primary'}
              onClick={handleWatch}
              className="flex-1"
            >
              {anime.is_premium ? <Crown className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
              {anime.is_premium ? t('anime.unlockWithPremium') : t('anime.watchNow')}
            </Button>
            <Button variant="outline" size="icon" onClick={handleFavorite}>
              <Bookmark className={cn('w-4 h-4', favorite && 'fill-secondary text-secondary')} />
            </Button>
            <Button variant="outline" size="icon" onClick={handleLike}>
              <Heart className={cn('w-4 h-4', isLiked && 'fill-error text-error')} />
            </Button>
            <Button variant="outline" size="icon" onClick={handleShare}>
              <Share2 className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Description */}
        <GlassCard className="p-4">
          <h3 className="text-sm font-semibold text-text-primary mb-2">
            {t('anime.description')}
          </h3>
          <p className="text-sm text-text-secondary leading-relaxed">
            {anime.description.en}
          </p>
          <div className="flex items-center gap-2 mt-3 text-xs text-text-muted">
            <span>{t('anime.studio')}: {anime.studio}</span>
          </div>
        </GlassCard>

        {/* Seasons */}
        {seasons.length > 0 && (
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {seasons.map((season) => (
              <button
                key={season.id}
                onClick={() => setSelectedSeason(season.id)}
                className={cn(
                  'px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all',
                  selectedSeason === season.id
                    ? 'bg-primary text-white shadow-neon'
                    : 'bg-surface text-text-secondary border border-border'
                )}
              >
                Season {season.number}
              </button>
            ))}
          </div>
        )}

        {/* Episodes */}
        {episodes.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-text-primary">
                {t('anime.episodes')} ({episodes.length})
              </h3>
              {episodes.length > 3 && (
                <button
                  onClick={() => setShowAllEpisodes((prev) => !prev)}
                  className="text-xs text-primary font-medium"
                >
                  {showAllEpisodes ? t('common.close') : `${t('common.all')} (${episodes.length})`}
                </button>
              )}
            </div>
            <EpisodeList
              episodes={visibleEpisodes}
              animeId={anime.id}
              onEpisodeClick={(ep) => {
                addHistory({
                  animeId: anime.id,
                  animeTitle: anime.title.en,
                  coverUrl: anime.cover_url,
                  episodeId: ep.id,
                  episodeTitle: ep.title.en,
                  progress: ep.progress ?? 0,
                  watchedAt: new Date().toISOString(),
                });
              }}
            />
          </div>
        )}

        {/* Recommendations */}
        {recommendations.length > 0 && (
          <div>
            <h3 className="text-sm font-semibold text-text-primary mb-3">
              {t('anime.recommendations')}
            </h3>
            <AnimeGrid items={recommendations} columns={3} />
          </div>
        )}
      </div>
    </main>
  );
}
