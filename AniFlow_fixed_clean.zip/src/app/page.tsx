'use client';

import { useMemo } from 'react';
import { TikTokFeed } from '@/components/feed/TikTokFeed';
import { useAnimeList } from '@/features/anime/useAnimeList';
import { useInfiniteScroll } from '@/hooks/useInfiniteScroll';
import { FEED_PAGE_SIZE } from '@/config/constants';
import type { Anime } from '@/types/anime';

export default function HomePage() {
  const {
    data,
    isLoading,
    isError,
    hasNextPage,
    fetchNextPage,
    isFetchingNextPage,
  } = useAnimeList({
    params: {
      limit: FEED_PAGE_SIZE,
      sort: 'popular',
    },
  });

  const items = useMemo<Anime[]>(
    () => data?.pages.flatMap((page) => page.items) ?? [],
    [data]
  );

  const { sentinelRef } = useInfiniteScroll({
    hasMore: hasNextPage ?? false,
    isLoading: isFetchingNextPage,
    onLoadMore: () => fetchNextPage(),
  });

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="h-screen flex flex-col items-center justify-center gap-4 bg-background">
        <p className="text-text-muted">Failed to load feed</p>
        <button
          onClick={() => window.location.reload()}
          className="px-6 py-2 rounded-full bg-primary text-white text-sm font-medium"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <main className="h-screen bg-background">
      <TikTokFeed
        items={items}
        hasMore={hasNextPage ?? false}
        onEndReached={() => fetchNextPage()}
        isLoading={isFetchingNextPage}
      />
      <div ref={sentinelRef} />
    </main>
  );
}
