'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useQuery, useMutation } from 'react-query';
import { playerService } from '@/services/player.service';
import { useLanguage } from '@/i18n/LanguageProvider';
import { usePlayerStore } from '@/store/playerStore';
import { useLibraryStore } from '@/store/libraryStore';
import { usePremium } from '@/features/premium/usePremium';
import { useHaptic } from '@/hooks/useHaptic';
import { VerticalPlayer } from '@/components/player/VerticalPlayer';
import { PremiumOverlay } from '@/components/player/PremiumOverlay';
import { GlassCard } from '@/components/common/GlassCard';
import { Badge } from '@/components/common/Badge';
import { Button } from '@/components/common/Button';
import { Skeleton } from '@/components/common/Skeleton';
import { ChevronLeft, Heart, Share2, ThumbsUp, ListVideo } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { cn, formatDuration, formatNumber } from '@/lib/utils';
import type { Episode } from '@/types/episode';

export default function WatchPage() {
  const { episodeId } = useParams<{ episodeId: string }>();
  const router = useRouter();
  const { t } = useLanguage();
  const { impact } = useHaptic();
  const { isPremium } = usePremium();
  const { addHistory, addContinueWatching } = useLibraryStore();
  const [isLiked, setIsLiked] = useState(false);
  const [showEpisodes, setShowEpisodes] = useState(false);
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const {
    data: episode,
    isLoading,
    error,
  } = useQuery<Episode>(['player', 'episode', episodeId], () =>
    playerService.getEpisode(episodeId)
  );

  const saveProgressMutation = useMutation(
    ({ id, progress }: { id: string; progress: number }) =>
      playerService.saveProgress(id, progress)
  );

  const { data: nextEpisode } = useQuery<Episode | null>(
    ['player', 'next', episodeId],
    () => playerService.getNextEpisode(episodeId),
    { enabled: !!episodeId }
  );

  const hasAccess = isPremium || (episode ? episode.is_free : true);

  const persistProgress = useCallback(
    (progress: number) => {
      if (!episode || !Number.isFinite(progress)) return;

      const clampedProgress = Math.max(0, Math.min(progress, 1));
      saveProgressMutation.mutate({ id: episode.id, progress: clampedProgress });
      addHistory({
        animeId: episode.anime_id,
        episodeId: episode.id,
        animeTitle: episode.title.en,
        episodeTitle: episode.title.en,
        coverUrl: episode.thumbnail_url,
        progress: clampedProgress,
        watchedAt: new Date().toISOString(),
      });
    },
    [addHistory, episode, saveProgressMutation]
  );

  // Save progress periodically
  useEffect(() => {
    if (!episode) return;

    const interval = setInterval(() => {
      const { currentTime, duration } = usePlayerStore.getState();
      if (duration > 0 && currentTime > 0) {
        persistProgress(currentTime / duration);
      }
    }, 15000);

    return () => clearInterval(interval);
  }, [episode, persistProgress]);

  // Save on unmount
  useEffect(() => {
    return () => {
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
      const { currentTime, duration } = usePlayerStore.getState();
      if (episode && duration > 0 && currentTime > 0) {
        const progress = currentTime / duration;
        persistProgress(progress);
        addContinueWatching({
          anime: {
            id: episode.anime_id,
            title: { en: episode.title.en, uk: episode.title.en, ru: episode.title.en },
            description: { en: '', uk: '', ru: '' },
            cover_url: episode.thumbnail_url,
            banner_url: episode.thumbnail_url,
            studio: '',
            genres: [],
            status: 'ongoing',
            rating: 0,
            views: 0,
            likes: 0,
            is_premium: !episode.is_free,
            created_at: new Date().toISOString(),
          },
          episode,
          progress,
          last_watched_at: new Date().toISOString(),
        });
      }
    };
  }, [addContinueWatching, episode, persistProgress]);

  const handlePlayerProgress = useCallback(
    (progress: number) => {
      if (!episode) return;
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
      saveTimerRef.current = setTimeout(() => persistProgress(progress), 5000);
    },
    [episode, persistProgress]
  );

  const handleLike = () => {
    impact('light');
    setIsLiked((prev) => {
      const newVal = !prev;
      if (newVal && episode) {
        playerService.likeEpisode(episode.id).catch(() => {});
      }
      return newVal;
    });
  };

  const handleShare = async () => {
    impact('medium');
    try {
      await navigator.share({
        title: episode?.title.en ?? 'AniFlow',
        url: window.location.href,
      });
    } catch {
      // User cancelled
    }
  };

  const handleNextEpisode = () => {
    if (nextEpisode) {
      router.push(`/watch/${nextEpisode.id}`);
    }
  };

  if (isLoading) {
    return (
      <main className="h-screen bg-black safe-top">
        {/* Header */}
        <div className="flex items-center justify-between p-4">
          <button
            onClick={() => router.back()}
            className="p-2 rounded-full bg-white/10 text-white"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <Skeleton className="w-32 h-4" />
          <div className="w-9" />
        </div>

        <div className="flex-1 flex flex-col items-center justify-center gap-4">
          <Skeleton variant="rect" className="w-full max-w-md aspect-video" />
          <div className="w-full max-w-md px-4 space-y-3">
            <Skeleton variant="text" className="w-2/3 mx-auto" />
            <Skeleton variant="text" className="w-1/2 mx-auto" />
          </div>
        </div>
      </main>
    );
  }

  if (error || !episode) {
    return (
      <main className="h-screen bg-black safe-top flex items-center justify-center px-4">
        <div className="text-center space-y-4">
          <p className="text-text-muted">{t('common.error')}</p>
          <Button variant="primary" onClick={() => router.back()}>
            {t('common.back')}
          </Button>
        </div>
      </main>
    );
  }

  return (
    <main className="h-screen bg-black safe-top flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 z-20">
        <button
          onClick={() => router.back()}
          className="p-2 rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2">
          <span className="text-sm text-white/80 font-medium">
            {episode.title.en}
          </span>
          {!episode.is_free && !isPremium && <Badge variant="premium">PREMIUM</Badge>}
        </div>
        <button
          onClick={() => setShowEpisodes((prev) => !prev)}
          className={cn(
            'p-2 rounded-full transition-colors',
            showEpisodes
              ? 'bg-primary text-white'
              : 'bg-white/10 text-white hover:bg-white/20'
          )}
        >
          <ListVideo className="w-5 h-5" />
        </button>
      </div>

      {/* Player */}
      <div className="flex-1 relative">
        {hasAccess ? (
          <VerticalPlayer
            episode={episode}
            hasAccess={hasAccess}
            onProgress={handlePlayerProgress}
            onEnded={handleNextEpisode}
          />
        ) : (
          <PremiumOverlay episode={episode} />
        )}

        {/* Episode info */}
        <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black via-black/60 to-transparent z-10">
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="episode">
              {t('home.episode')} {episode.number}
            </Badge>
            <span className="text-xs text-white/60">
              {formatDuration(episode.duration)}
            </span>
            <span className="text-xs text-white/60 flex items-center gap-1">
              <ThumbsUp className="w-3 h-3" />
              {formatNumber(episode.views)}
            </span>
          </div>

          <h2 className="text-lg font-semibold text-white mb-3">
            {episode.title.en}
          </h2>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {nextEpisode && (
              <Button
                variant="primary"
                size="sm"
                onClick={handleNextEpisode}
                className="flex-1"
              >
                {t('player.nextEpisode')}
                <ChevronLeft className="w-4 h-4 rotate-180" />
              </Button>
            )}
            <Button
              variant="outline"
              size="icon"
              onClick={handleLike}
              className="bg-white/10 border-white/20"
            >
              <Heart
                className={cn('w-4 h-4', isLiked && 'fill-error text-error')}
              />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={handleShare}
              className="bg-white/10 border-white/20"
            >
              <Share2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Episodes panel */}
      {showEpisodes && (
        <div className="absolute inset-0 z-30 bg-black/80 backdrop-blur-sm flex flex-col">
          <div className="p-4 border-b border-white/10 flex items-center justify-between">
            <h3 className="text-white font-semibold">{t('anime.episodes')}</h3>
            <button
              onClick={() => setShowEpisodes(false)}
              className="p-2 rounded-full bg-white/10 text-white"
            >
              <ChevronLeft className="w-4 h-4 rotate-90" />
            </button>
          </div>
          <EpisodeListMini
            currentEpisodeId={episode.id}
            onSelect={(ep) => {
              setShowEpisodes(false);
              router.push(`/watch/${ep.id}`);
            }}
          />
        </div>
      )}
    </main>
  );
}

function EpisodeListMini({
  currentEpisodeId: _currentEpisodeId,
  onSelect: _onSelect,
}: {
  currentEpisodeId: string;
  onSelect: (ep: Episode) => void;
}) {
  const { episodeId } = useParams<{ episodeId: string }>();
  const { t } = useLanguage();
  const { data: episodes } = useQuery<Episode[]>(
    ['player', 'episodes', episodeId],
    () => playerService.getEpisode(episodeId).then((ep) => [ep])
  );

  // We only have the current episode; a full list would come from the anime service
  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-2">
      <GlassCard className="p-3 flex items-center gap-3">
        <div className="relative w-24 h-14 flex-shrink-0 overflow-hidden rounded-lg">
          {episodes?.[0]?.thumbnail_url && (
            <Image
              src={episodes[0].thumbnail_url}
              alt={episodes[0].title.en}
              fill
              sizes="96px"
              className="w-full h-full object-cover"
            />
          )}
          <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
            <ThumbsUp className="w-4 h-4 text-white" />
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-medium text-white truncate">
            {episodes?.[0]?.title.en}
          </h4>
          <p className="text-xs text-white/60">
            {t('home.episode')} {episodes?.[0]?.number}
          </p>
        </div>
        <Link
          href={`/anime/${episodes?.[0]?.anime_id}`}
          className="text-xs text-primary font-medium"
        >
          {t('anime.episodes')}
        </Link>
      </GlassCard>
    </div>
  );
}
