'use client';

import { FormEvent, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from 'react-query';
import { adminService } from '@/services/admin.service';
import { useAuth } from '@/features/auth/useAuth';
import { Button } from '@/components/common/Button';
import { GlassCard } from '@/components/common/GlassCard';
import { Skeleton } from '@/components/common/Skeleton';
import { Badge } from '@/components/common/Badge';
import {
  Ban,
  BarChart3,
  CalendarClock,
  Clapperboard,
  Crown,
  EyeOff,
  Image as ImageIcon,
  Layers,
  Plus,
  Upload,
  Users,
  Video,
} from 'lucide-react';

const EMPTY_TITLE = { en: '', uk: '', ru: '' };

export default function AdminPage() {
  const queryClient = useQueryClient();
  const { user, isLoading: isAuthLoading } = useAuth();
  const [animeId, setAnimeId] = useState('');
  const [episodeId, setEpisodeId] = useState('');
  const [userId, setUserId] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [genres, setGenres] = useState('Action, Fantasy');
  const [seasonNumber, setSeasonNumber] = useState(1);
  const [episodeNumber, setEpisodeNumber] = useState(1);
  const [videoUrl, setVideoUrl] = useState('');
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [scheduledAt, setScheduledAt] = useState('');

  const statsQuery = useQuery(['admin', 'stats'], () => adminService.getStats(), {
    enabled: !!user?.is_admin,
    staleTime: 30 * 1000,
  });

  const createAnime = useMutation(
    () =>
      adminService.uploadAnime({
        title: { en: title, uk: title, ru: title },
        description: { en: description, uk: description, ru: description },
        cover_url: thumbnailUrl,
        banner_url: thumbnailUrl,
        studio: 'AniFlow',
        genres: genres.split(',').map((genre) => genre.trim()).filter(Boolean),
        status: 'ongoing',
        rating: 0,
        views: 0,
        likes: 0,
        is_premium: false,
        created_at: new Date().toISOString(),
      }),
    {
      onSuccess: (anime) => {
        setAnimeId(anime.id);
        queryClient.invalidateQueries(['admin', 'stats']);
      },
    }
  );

  const createSeason = useMutation(() =>
    adminService.createSeason(animeId, {
      number: seasonNumber,
      title: { ...EMPTY_TITLE, en: `Season ${seasonNumber}` },
    })
  );

  const createEpisode = useMutation(
    () =>
      adminService.createEpisode(animeId, {
        anime_id: animeId,
        season_id: '',
        number: episodeNumber,
        title: { en: title || `Episode ${episodeNumber}`, uk: title || `Episode ${episodeNumber}`, ru: title || `Episode ${episodeNumber}` },
        video_url: videoUrl,
        thumbnail_url: thumbnailUrl,
        duration: 0,
        is_free: episodeNumber <= 3,
        views: 0,
        likes: 0,
        scheduled_at: scheduledAt || undefined,
      }),
    {
      onSuccess: (episode) => setEpisodeId(episode.id),
    }
  );

  const hideAnime = useMutation(() => adminService.setAnimeHidden(animeId, true));
  const scheduleEpisode = useMutation(() => adminService.scheduleEpisode(episodeId, scheduledAt));
  const grantPremium = useMutation(() => adminService.grantPremium(userId));
  const banUser = useMutation(() => adminService.banUser(userId));

  const handleFileUpload = (type: 'cover' | 'video', file?: File) => {
    if (!file) return;
    if (type === 'cover' && animeId) {
      adminService.uploadCover(animeId, file).then(() => queryClient.invalidateQueries(['admin']));
    }
    if (type === 'video' && episodeId) {
      adminService.uploadVideo(episodeId, file).then(() => queryClient.invalidateQueries(['admin']));
    }
  };

  const submit = (event: FormEvent, action: () => void) => {
    event.preventDefault();
    action();
  };

  if (isAuthLoading) {
    return (
      <main className="min-h-screen bg-background safe-top p-4">
        <Skeleton className="h-28 w-full" />
      </main>
    );
  }

  if (!user?.is_admin) {
    return (
      <main className="min-h-screen bg-background safe-top flex items-center justify-center p-4">
        <GlassCard className="p-6 text-center max-w-sm">
          <Crown className="w-8 h-8 text-primary mx-auto mb-3" />
          <h1 className="text-lg font-semibold text-text-primary">Admin only</h1>
          <p className="text-sm text-text-muted mt-2">Telegram auth must return an admin user.</p>
        </GlassCard>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-background safe-top px-4 pt-4 pb-10">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-display font-bold neon-text">Admin</h1>
        <Badge variant="premium">Dashboard</Badge>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-5">
        <Stat icon={Users} label="Users" value={statsQuery.data?.totalUsers ?? 0} />
        <Stat icon={Clapperboard} label="Anime" value={statsQuery.data?.totalAnime ?? 0} />
        <Stat icon={BarChart3} label="Views" value={statsQuery.data?.totalViews ?? 0} />
        <Stat icon={Crown} label="Premium" value={statsQuery.data?.premiumUsers ?? 0} />
      </div>

      <div className="space-y-4">
        <GlassCard className="p-4">
          <h2 className="text-sm font-semibold mb-3 flex items-center gap-2">
            <Plus className="w-4 h-4 text-primary" /> Add / edit anime
          </h2>
          <form className="space-y-3" onSubmit={(event) => submit(event, () => createAnime.mutate())}>
            <Input value={title} onChange={setTitle} placeholder="Title" />
            <Input value={description} onChange={setDescription} placeholder="Description" />
            <Input value={genres} onChange={setGenres} placeholder="Genres comma separated" />
            <Input value={thumbnailUrl} onChange={setThumbnailUrl} placeholder="Cover or banner URL" />
            <Button type="submit" loading={createAnime.isLoading} fullWidth>
              <Plus className="w-4 h-4" /> Save anime
            </Button>
          </form>
        </GlassCard>

        <GlassCard className="p-4 space-y-3">
          <h2 className="text-sm font-semibold flex items-center gap-2">
            <Layers className="w-4 h-4 text-primary" /> Seasons and episodes
          </h2>
          <Input value={animeId} onChange={setAnimeId} placeholder="Anime ID" />
          <Input value={String(seasonNumber)} onChange={(value) => setSeasonNumber(Number(value) || 1)} placeholder="Season number" type="number" />
          <Button onClick={() => createSeason.mutate()} loading={createSeason.isLoading} fullWidth>
            <Layers className="w-4 h-4" /> Create season
          </Button>
          <Input value={String(episodeNumber)} onChange={(value) => setEpisodeNumber(Number(value) || 1)} placeholder="Episode number" type="number" />
          <Input value={videoUrl} onChange={setVideoUrl} placeholder="Video URL" />
          <Input value={scheduledAt} onChange={setScheduledAt} placeholder="Scheduled ISO date" />
          <Button onClick={() => createEpisode.mutate()} loading={createEpisode.isLoading} fullWidth>
            <Video className="w-4 h-4" /> Create episode
          </Button>
        </GlassCard>

        <GlassCard className="p-4 space-y-3">
          <h2 className="text-sm font-semibold flex items-center gap-2">
            <Upload className="w-4 h-4 text-primary" /> Uploads and moderation
          </h2>
          <Input value={episodeId} onChange={setEpisodeId} placeholder="Episode ID" />
          <label className="flex items-center justify-between gap-3 rounded-xl border border-border bg-surface2 px-4 py-3 text-sm">
            <span className="flex items-center gap-2"><ImageIcon className="w-4 h-4" /> Cover</span>
            <input type="file" accept="image/*" className="w-36 text-xs" onChange={(event) => handleFileUpload('cover', event.target.files?.[0])} />
          </label>
          <label className="flex items-center justify-between gap-3 rounded-xl border border-border bg-surface2 px-4 py-3 text-sm">
            <span className="flex items-center gap-2"><Video className="w-4 h-4" /> Video</span>
            <input type="file" accept="video/*" className="w-36 text-xs" onChange={(event) => handleFileUpload('video', event.target.files?.[0])} />
          </label>
          <Button variant="outline" onClick={() => scheduleEpisode.mutate()} loading={scheduleEpisode.isLoading} fullWidth>
            <CalendarClock className="w-4 h-4" /> Schedule episode
          </Button>
          <Button variant="danger" onClick={() => hideAnime.mutate()} loading={hideAnime.isLoading} fullWidth>
            <EyeOff className="w-4 h-4" /> Hide anime
          </Button>
        </GlassCard>

        <GlassCard className="p-4 space-y-3">
          <h2 className="text-sm font-semibold flex items-center gap-2">
            <Users className="w-4 h-4 text-primary" /> Users
          </h2>
          <Input value={userId} onChange={setUserId} placeholder="User ID" />
          <div className="grid grid-cols-2 gap-2">
            <Button variant="premium" onClick={() => grantPremium.mutate()} loading={grantPremium.isLoading}>
              <Crown className="w-4 h-4" /> Premium
            </Button>
            <Button variant="danger" onClick={() => banUser.mutate()} loading={banUser.isLoading}>
              <Ban className="w-4 h-4" /> Ban
            </Button>
          </div>
        </GlassCard>
      </div>
    </main>
  );
}

function Stat({ icon: Icon, label, value }: { icon: typeof Users; label: string; value: number }) {
  return (
    <GlassCard className="p-4">
      <Icon className="w-5 h-5 text-primary mb-2" />
      <p className="text-2xl font-display font-bold">{value}</p>
      <p className="text-xs text-text-muted">{label}</p>
    </GlassCard>
  );
}

function Input({
  value,
  onChange,
  placeholder,
  type = 'text',
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  type?: string;
}) {
  return (
    <input
      type={type}
      value={value}
      onChange={(event) => onChange(event.target.value)}
      placeholder={placeholder}
      className="w-full rounded-xl border border-border bg-surface2 px-4 py-3 text-sm text-text-primary placeholder:text-text-muted focus:outline-none focus:border-primary/60"
    />
  );
}
