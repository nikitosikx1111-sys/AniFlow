'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/i18n/LanguageProvider';
import { useAuth } from '@/features/auth/useAuth';
import { GlassCard } from '@/components/common/GlassCard';
import { Badge } from '@/components/common/Badge';
import { Button } from '@/components/common/Button';
import {
  ChevronLeft,
  Moon,
  Sun,
  Monitor,
  Bell,
  Shield,
  HelpCircle,
  Info,
  LogOut,
  ChevronRight,
  Languages,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { APP_VERSION } from '@/config/constants';
import type { Language } from '@/types/user';
import { languages } from '@/i18n';

type ThemeMode = 'dark' | 'light' | 'system';

const THEME_OPTIONS: { key: ThemeMode; icon: typeof Moon; labelKey: string }[] = [
  { key: 'dark', icon: Moon, labelKey: 'settings.dark' },
  { key: 'light', icon: Sun, labelKey: 'settings.light' },
  { key: 'system', icon: Monitor, labelKey: 'settings.system' },
];

export default function SettingsPage() {
  const router = useRouter();
  const { t, language, setLanguage } = useLanguage();
  const { logout } = useAuth();
  const [theme, setTheme] = useState<ThemeMode>('dark');
  const [notifications, setNotifications] = useState(true);

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
  };

  const handleLogout = async () => {
    await logout();
    router.push('/');
  };

  return (
    <main className="min-h-screen bg-background safe-top">
      <div className="px-4 pt-4 pb-8 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => router.back()}
            className="p-2 rounded-xl bg-surface text-text-secondary hover:text-text-primary transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-display font-bold neon-text">
            {t('settings.title')}
          </h1>
        </div>

        {/* Appearance */}
        <div>
          <h2 className="text-sm font-semibold text-text-primary mb-3">
            {t('settings.theme')}
          </h2>
          <div className="grid grid-cols-3 gap-2">
            {THEME_OPTIONS.map((option) => {
              const Icon = option.icon;
              const isActive = theme === option.key;
              return (
                <button
                  key={option.key}
                  onClick={() => setTheme(option.key)}
                  className={cn(
                    'flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all',
                    isActive
                      ? 'border-primary bg-primary/10 shadow-neon'
                      : 'border-border bg-surface hover:border-primary/50'
                  )}
                >
                  <Icon
                    className={cn(
                      'w-5 h-5',
                      isActive ? 'text-primary' : 'text-text-secondary'
                    )}
                  />
                  <span
                    className={cn(
                      'text-xs font-medium',
                      isActive ? 'text-text-primary' : 'text-text-secondary'
                    )}
                  >
                    {t(option.labelKey)}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Language */}
        <div>
          <h2 className="text-sm font-semibold text-text-primary mb-3">
            {t('settings.language')}
          </h2>
          <GlassCard className="p-2">
            {languages.map((lang, index) => (
              <button
                key={lang.code}
                onClick={() => handleLanguageChange(lang.code)}
                className={cn(
                  'w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors',
                  language === lang.code
                    ? 'bg-primary/10 text-primary'
                    : 'text-text-secondary hover:bg-surface2',
                  index > 0 && 'border-t border-border'
                )}
              >
                <Languages className="w-4 h-4" />
                <span className="flex-1 text-left text-sm font-medium">
                  {lang.native}
                </span>
                <span className="text-xs text-text-muted">{lang.label}</span>
                {language === lang.code && (
                  <Badge variant="free">✓</Badge>
                )}
              </button>
            ))}
          </GlassCard>
        </div>

        {/* Notifications */}
        <div>
          <h2 className="text-sm font-semibold text-text-primary mb-3">
            {t('settings.notifications')}
          </h2>
          <GlassCard className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-xl bg-surface2">
              <Bell className="w-5 h-5 text-text-secondary" />
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-medium text-text-primary">
                {t('settings.notifications')}
              </h3>
              <p className="text-xs text-text-muted">
                New episodes, discounts & rewards
              </p>
            </div>
            <button
              onClick={() => setNotifications((prev) => !prev)}
              className={cn(
                'relative w-12 h-7 rounded-full transition-colors',
                notifications ? 'bg-primary' : 'bg-surface2 border border-border'
              )}
            >
              <div
                className={cn(
                  'absolute top-1 w-5 h-5 rounded-full bg-white transition-all',
                  notifications ? 'left-6' : 'left-1'
                )}
              />
            </button>
          </GlassCard>
        </div>

        {/* About */}
        <div>
          <h2 className="text-sm font-semibold text-text-primary mb-3">
            {t('settings.about')}
          </h2>
          <div className="space-y-2">
            <GlassCard className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-xl bg-surface2">
                <Info className="w-5 h-5 text-text-secondary" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-medium text-text-primary">
                  {t('app.name')}
                </h3>
                <p className="text-xs text-text-muted">
                  {t('settings.version')} {APP_VERSION}
                </p>
              </div>
              <ChevronRight className="w-4 h-4 text-text-muted" />
            </GlassCard>

            <GlassCard className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-xl bg-surface2">
                <Shield className="w-5 h-5 text-text-secondary" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-medium text-text-primary">
                  {t('settings.privacyPolicy')}
                </h3>
              </div>
              <ChevronRight className="w-4 h-4 text-text-muted" />
            </GlassCard>

            <GlassCard className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-xl bg-surface2">
                <HelpCircle className="w-5 h-5 text-text-secondary" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-medium text-text-primary">
                  {t('settings.support')}
                </h3>
              </div>
              <ChevronRight className="w-4 h-4 text-text-muted" />
            </GlassCard>
          </div>
        </div>

        {/* Logout */}
        <Button
          variant="danger"
          fullWidth
          size="lg"
          onClick={handleLogout}
        >
          <LogOut className="w-4 h-4" />
          {t('common.delete')}
        </Button>

        <p className="text-center text-xs text-text-muted">
          {t('app.name')} v{APP_VERSION} • Made with 💜
        </p>
      </div>
    </main>
  );
}
