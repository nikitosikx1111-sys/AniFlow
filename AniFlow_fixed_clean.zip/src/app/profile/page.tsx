'use client';

import { useLanguage } from '@/i18n/LanguageProvider';
import { useAuth } from '@/features/auth/useAuth';
import { useTelegram } from '@/hooks/useTelegram';
import { usePremium } from '@/features/premium/usePremium';
import { useReferral } from '@/features/referral/useReferral';
import { GlassCard } from '@/components/common/GlassCard';
import { Badge } from '@/components/common/Badge';
import { Button } from '@/components/common/Button';
import { Crown, Settings, Share2, ChevronRight, Star, User as UserIcon, Gift } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { useUIStore } from '@/store/uiStore';

export default function ProfilePage() {
  const { t } = useLanguage();
  const { user } = useTelegram();
  const { user: authUser } = useAuth();
  const { isPremium, expiresAt } = usePremium();
  const { referralInfo } = useReferral();
  const referralCode = referralInfo?.code;
  const referralCount = referralInfo?.referral_count ?? 0;
  const totalEarned = referralInfo?.total_earned ?? 0;
  const { openPremiumModal } = useUIStore();

  const displayName = authUser?.username ?? user?.username ?? 'Anime Fan';
  const avatarUrl = user?.photo_url ?? authUser?.avatar_url;

  const handleShare = async () => {
    try {
      await navigator.share({
        title: t('app.name'),
        text: t('referral.inviteFriends'),
        url: `https://t.me/share/url?url=${encodeURIComponent(referralCode ?? '')}&text=${encodeURIComponent(t('referral.inviteFriends'))}`,
      });
    } catch {
      // User cancelled
    }
  };

  return (
    <main className="min-h-screen bg-background safe-top">
      <div className="px-4 pt-4 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-display font-bold neon-text">
            {t('nav.profile')}
          </h1>
          <Link
            href="/settings"
            className="p-2 rounded-xl bg-surface text-text-secondary hover:text-text-primary transition-colors"
          >
            <Settings className="w-5 h-5" />
          </Link>
        </div>

        {/* User card */}
        <GlassCard className="p-5 flex items-center gap-4">
          <div className="relative w-16 h-16 rounded-full overflow-hidden bg-surface2 border border-border flex-shrink-0">
            {avatarUrl ? (
              <Image
                src={avatarUrl}
                alt={displayName}
                fill
                className="object-cover"
                sizes="64px"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <UserIcon className="w-8 h-8 text-text-muted" />
              </div>
            )}
            {isPremium && (
              <div className="absolute -bottom-1 -right-1 p-1 rounded-full bg-gradient-to-r from-accent to-primary">
                <Crown className="w-3.5 h-3.5 text-white" />
              </div>
            )}
          </div>

          <div className="flex-1 min-w-0">
            <h2 className="text-lg font-semibold text-text-primary truncate">
              {displayName}
            </h2>
            <p className="text-sm text-text-muted">
              {isPremium ? t('premium.title') : 'Free user'}
            </p>
            {isPremium && expiresAt && (
              <p className="text-xs text-text-muted mt-0.5">
                Expires: {new Date(expiresAt).toLocaleDateString()}
              </p>
            )}
          </div>

          {!isPremium && (
            <Button
              variant="premium"
              size="sm"
              onClick={() => openPremiumModal()}
            >
              <Star className="w-3.5 h-3.5 fill-current" />
              {t('premium.subscribe')}
            </Button>
          )}
        </GlassCard>

        {/* Premium status */}
        {isPremium && (
          <GlassCard className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-gradient-to-r from-accent via-primary to-secondary">
                <Crown className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-semibold text-text-primary">
                  {t('premium.title')}
                </h3>
                <p className="text-xs text-text-muted">
                  {t('premium.benefits.unlimited')}
                </p>
              </div>
              <Badge variant="premium">Active</Badge>
            </div>
          </GlassCard>
        )}

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          <GlassCard className="p-3 text-center">
            <p className="text-2xl font-display font-bold text-text-primary">
              {referralCount}
            </p>
            <p className="text-xs text-text-muted mt-1">{t('referral.referralCount')}</p>
          </GlassCard>
          <GlassCard className="p-3 text-center">
            <p className="text-2xl font-display font-bold text-text-primary">
              {totalEarned}
            </p>
            <p className="text-xs text-text-muted mt-1">{t('referral.totalEarned')}</p>
          </GlassCard>
          <GlassCard className="p-3 text-center">
            <p className="text-2xl font-display font-bold text-text-primary text-gradient">
              ★
            </p>
            <p className="text-xs text-text-muted mt-1">Stars</p>
          </GlassCard>
        </div>

        {/* Referral */}
        <GlassCard className="p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 rounded-xl bg-secondary/15">
              <Gift className="w-5 h-5 text-secondary" />
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-text-primary">
                {t('referral.title')}
              </h3>
              <p className="text-xs text-text-muted">{t('referral.subtitle')}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex-1 px-4 py-3 rounded-xl bg-surface2 border border-border font-mono text-sm text-text-primary">
              {referralCode ?? 'N/A'}
            </div>
            <Button variant="secondary" size="sm" onClick={handleShare}>
              <Share2 className="w-4 h-4" />
              {t('referral.share')}
            </Button>
          </div>
        </GlassCard>

        {/* Menu */}
        <div className="space-y-2">
          <Link href="/premium">
            <GlassCard className="p-4 flex items-center gap-3 glass-card-hover">
              <div className="p-2 rounded-xl bg-primary/15">
                <Crown className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-medium text-text-primary">Premium</h3>
                <p className="text-xs text-text-muted">{t('premium.subtitle')}</p>
              </div>
              <ChevronRight className="w-4 h-4 text-text-muted" />
            </GlassCard>
          </Link>

          <Link href="/settings">
            <GlassCard className="p-4 flex items-center gap-3 glass-card-hover">
              <div className="p-2 rounded-xl bg-surface2">
                <Settings className="w-5 h-5 text-text-secondary" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-medium text-text-primary">{t('app.settings')}</h3>
                <p className="text-xs text-text-muted">{t('settings.notifications')}</p>
              </div>
              <ChevronRight className="w-4 h-4 text-text-muted" />
            </GlassCard>
          </Link>
        </div>
      </div>
    </main>
  );
}
