import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import { Inter, Space_Grotesk } from 'next/font/google';
import { APP_NAME } from '@/config/constants';
import { Providers } from './providers';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-space-grotesk',
  display: 'swap',
});

export const metadata: Metadata = {
  title: {
    default: `${APP_NAME} - AI Anime Universe`,
    template: `%s | ${APP_NAME}`,
  },
  description: 'Stream anime with AI-powered recommendations. Premium anime, exclusive content, and more.',
  keywords: ['anime', 'streaming', 'AI', 'premium', 'AniFlow'],
  authors: [{ name: 'AniFlow' }],
  openGraph: {
    title: `${APP_NAME} - AI Anime Universe`,
    description: 'Stream anime with AI-powered recommendations.',
    type: 'website',
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: '#0a0a0f',
};

export default function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body
        className={`${inter.variable} ${spaceGrotesk.variable} font-sans bg-background text-text-primary antialiased`}
      >
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
