'use client';

import { useMemo, useState } from 'react';
import { AnimeGrid } from '@/components/anime/AnimeGrid';
import { GlassCard } from '@/components/common/GlassCard';
import { Badge } from '@/components/common/Badge';
import { useAnimeList } from '@/features/anime/useAnimeList';
import { useInfiniteScroll } from '@/hooks/useInfiniteScroll';
import { useDebounce } from '@/hooks/useDebounce';
import { useLanguage } from '@/i18n/LanguageProvider';
import { SUPPORTED_GENRES, EXPLORE_PAGE_SIZE } from '@/config/constants';
import { Search, SlidersHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { AnimeListParams } from '@/types/anime';

const SORT_OPTIONS: { key: NonNullable<AnimeListParams['sort']>; labelKey: string }[] = [
  { key: 'popular', labelKey: 'explore.popular' },
  { key: 'new', labelKey: 'explore.new' },
  { key: 'top_rated', labelKey: 'explore.topRated' },
  { key: 'ongoing', labelKey: 'explore.ongoing' },
  { key: 'completed', labelKey: 'explore.completed' },
];

export default function ExplorePage() {
  const { t } = useLanguage();
  const [search, setSearch] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<string | undefined>();
  const [selectedSort, setSelectedSort] = useState<AnimeListParams['sort']>('popular');
  const [showFilters, setShowFilters] = useState(false);

  const debouncedSearch = useDebounce(search, 300);

  const params = useMemo<AnimeListParams>(
    () => ({
      limit: EXPLORE_PAGE_SIZE,
      search: debouncedSearch || undefined,
      genre: selectedGenre,
      sort: selectedSort,
    }),
    [debouncedSearch, selectedGenre, selectedSort]
  );

  const {
    data,
    isLoading,
    isError,
    hasNextPage,
    fetchNextPage,
    isFetchingNextPage,
  } = useAnimeList({ params });

  const items = useMemo(
    () => data?.pages.flatMap((page) => page.items) ?? [],
    [data]
  );

  const { sentinelRef } = useInfiniteScroll({
    hasMore: hasNextPage ?? false,
    isLoading: isFetchingNextPage,
    onLoadMore: () => fetchNextPage(),
  });

  return (
    <main className="min-h-screen bg-background safe-top">
      <div className="px-4 pt-4 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-display font-bold neon-text">
            {t('explore.title')}
          </h1>
          <button
            onClick={() => setShowFilters((prev) => !prev)}
            className={cn(
              'p-2 rounded-xl transition-colors',
              showFilters
                ? 'bg-primary/20 text-primary'
                : 'bg-surface text-text-secondary hover:text-text-primary'
            )}
          >
            <SlidersHorizontal className="w-5 h-5" />
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t('explore.searchPlaceholder')}
            className="w-full pl-10 pr-4 py-3 rounded-2xl bg-surface border border-border text-sm placeholder:text-text-muted focus:outline-none focus:border-primary/50 transition-colors"
          />
        </div>

        {/* Sort options */}
        <div className="flex gap-2 overflow-x-auto no-scrollbar -mx-4 px-4">
          {SORT_OPTIONS.map((option) => (
            <button
              key={option.key}
              onClick={() => setSelectedSort(option.key)}
              className={cn(
                'px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all',
                selectedSort === option.key
                  ? 'bg-primary text-white shadow-neon'
                  : 'bg-surface text-text-secondary border border-border'
              )}
            >
              {t(option.labelKey)}
            </button>
          ))}
        </div>

        {/* Genre filters */}
        {showFilters && (
          <GlassCard className="p-4">
            <h3 className="text-sm font-medium text-text-primary mb-3">
              {t('explore.genres')}
            </h3>
            <div className="flex flex-wrap gap-2">
              <Badge
                variant={!selectedGenre ? 'hot' : 'default'}
                onClick={() => setSelectedGenre(undefined)}
                className="cursor-pointer"
              >
                {t('common.all')}
              </Badge>
              {SUPPORTED_GENRES.map((genre) => (
                <Badge
                  key={genre}
                  variant={selectedGenre === genre ? 'hot' : 'default'}
                  onClick={() => setSelectedGenre(selectedGenre === genre ? undefined : genre)}
                  className="cursor-pointer"
                >
                  {genre}
                </Badge>
              ))}
            </div>
          </GlassCard>
        )}

        {/* Results */}
        <AnimeGrid
          items={items}
          isLoading={isLoading}
          hasMore={hasNextPage ?? false}
          onLoadMore={() => fetchNextPage()}
        />
        <div ref={sentinelRef} />

        {isError && (
          <div className="text-center py-10">
            <p className="text-text-muted mb-4">{t('common.error')}</p>
            <button
              onClick={() => window.location.reload()}
              className="px-6 py-2 rounded-full bg-primary text-white text-sm font-medium"
            >
              {t('common.retry')}
            </button>
          </div>
        )}
      </div>
    </main>
  );
}
