'use client';

import { useMemo, useState } from 'react';
import { GlassCard } from '@/components/common/GlassCard';
import { Badge } from '@/components/common/Badge';
import { useLanguage } from '@/i18n/LanguageProvider';
import { useLibraryStore } from '@/store/libraryStore';
import { AnimeGrid } from '@/components/anime/AnimeGrid';
import { Bookmark, History, PlayCircle, Clock, Star } from 'lucide-react';
import { cn } from '@/lib/utils';
import Link from 'next/link';
import Image from 'next/image';
import type { Anime } from '@/types/anime';

type LibraryTab = 'favorites' | 'history' | 'continue';

const TABS: { key: LibraryTab; labelKey: string; icon: typeof Bookmark }[] = [
  { key: 'favorites', labelKey: 'library.favorites', icon: Bookmark },
  { key: 'continue', labelKey: 'library.continueWatching', icon: PlayCircle },
  { key: 'history', labelKey: 'library.history', icon: History },
];

export default function LibraryPage() {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<LibraryTab>('favorites');
  const { favorites, history, continueWatching } = useLibraryStore();

  const favoriteAnime = useMemo<Anime[]>(
    () =>
      favorites.map((fav) => ({
        id: fav.animeId,
        title: { en: fav.animeTitle, uk: fav.animeTitle, ru: fav.animeTitle },
        description: { en: '', uk: '', ru: '' },
        cover_url: fav.coverUrl,
        banner_url: fav.coverUrl,
        studio: '',
        genres: [],
        status: 'ongoing',
        rating: 0,
        views: 0,
        likes: 0,
        is_premium: false,
        created_at: fav.addedAt,
      })),
    [favorites]
  );

  const getEmptyState = () => {
    switch (activeTab) {
      case 'favorites':
        return {
          icon: Bookmark,
          title: t('library.emptyFavorites'),
          message: t('library.empty'),
        };
      case 'continue':
        return {
          icon: PlayCircle,
          title: t('library.emptyContinue'),
          message: t('library.empty'),
        };
      case 'history':
        return {
          icon: History,
          title: t('library.emptyHistory'),
          message: t('library.empty'),
        };
      default:
        return {
          icon: Bookmark,
          title: t('library.emptyFavorites'),
          message: t('library.empty'),
        };
    }
  };

  const emptyState = getEmptyState();

  return (
    <main className="min-h-screen bg-background safe-top">
      <div className="px-4 pt-4 space-y-4">
        {/* Header */}
        <h1 className="text-2xl font-display font-bold neon-text">
          {t('library.title')}
        </h1>

        {/* Tabs */}
        <div className="flex gap-2">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            const count =
              tab.key === 'favorites'
                ? favorites.length
                : tab.key === 'continue'
                ? continueWatching.length
                : history.length;

            return (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={cn(
                  'flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-medium transition-all',
                  isActive
                    ? 'bg-primary text-white shadow-neon'
                    : 'bg-surface text-text-secondary border border-border'
                )}
              >
                <Icon className="w-4 h-4" />
                <span className="hidden sm:inline">{t(tab.labelKey)}</span>
                <Badge variant={isActive ? 'hot' : 'default'}>{count}</Badge>
              </button>
            );
          })}
        </div>

        {/* Content */}
        {activeTab === 'favorites' && (
          <div>
            {favoriteAnime.length > 0 ? (
              <AnimeGrid items={favoriteAnime} columns={3} />
            ) : (
              <EmptyState
                icon={emptyState.icon}
                title={emptyState.title}
                message={emptyState.message}
              />
            )}
          </div>
        )}

        {activeTab === 'continue' && (
          <div className="space-y-3">
            {continueWatching.length > 0 ? (
              continueWatching.map((item) => (
                <Link
                  key={`${item.anime.id}-${item.episode.id}`}
                  href={`/watch/${item.episode.id}`}
                  className="block"
                >
                  <GlassCard className="p-3 flex items-center gap-3 glass-card-hover">
                    <div className="relative w-24 h-16 flex-shrink-0 overflow-hidden rounded-xl">
                      <Image
                        src={item.anime.cover_url}
                        alt={item.anime.title.en}
                        fill
                        sizes="96px"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/20" />
                      <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20">
                        <div
                          className="h-full bg-primary"
                          style={{ width: `${item.progress * 100}%` }}
                        />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-medium text-text-primary truncate">
                        {item.anime.title.en}
                      </h4>
                      <p className="text-xs text-text-muted mt-0.5">
                        {t('home.episode')} {item.episode.number}: {item.episode.title.en}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <Clock className="w-3.5 h-3.5 text-text-muted" />
                        <span className="text-xs text-text-muted">
                          {Math.round(item.progress * 100)}%
                        </span>
                      </div>
                    </div>
                    <PlayCircle className="w-6 h-6 text-primary flex-shrink-0" />
                  </GlassCard>
                </Link>
              ))
            ) : (
              <EmptyState
                icon={emptyState.icon}
                title={emptyState.title}
                message={emptyState.message}
              />
            )}
          </div>
        )}

        {activeTab === 'history' && (
          <div className="space-y-3">
            {history.length > 0 ? (
              history.map((item) => (
                <Link
                  key={item.animeId}
                  href={`/anime/${item.animeId}`}
                  className="block"
                >
                  <GlassCard className="p-3 flex items-center gap-3 glass-card-hover">
                    <div className="relative w-24 h-16 flex-shrink-0 overflow-hidden rounded-xl">
                      <Image
                        src={item.coverUrl}
                        alt={item.animeTitle}
                        fill
                        sizes="96px"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-medium text-text-primary truncate">
                        {item.animeTitle}
                      </h4>
                      <p className="text-xs text-text-muted mt-0.5">
                        {new Date(item.watchedAt).toLocaleDateString()}
                      </p>
                    </div>
                    <Star className="w-5 h-5 text-warning/50 flex-shrink-0" />
                  </GlassCard>
                </Link>
              ))
            ) : (
              <EmptyState
                icon={emptyState.icon}
                title={emptyState.title}
                message={emptyState.message}
              />
            )}
          </div>
        )}
      </div>
    </main>
  );
}

function EmptyState({
  icon: Icon,
  title,
  message,
}: {
  icon: typeof Bookmark;
  title: string;
  message: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="p-4 rounded-full bg-surface border border-border mb-4">
        <Icon className="w-8 h-8 text-text-muted" />
      </div>
      <h3 className="text-base font-medium text-text-primary mb-1">{title}</h3>
      <p className="text-sm text-text-muted">{message}</p>
    </div>
  );
}
