'use client';

import { useState } from 'react';
import { useLanguage } from '@/i18n/LanguageProvider';
import {
  usePaymentHistory,
  usePremium,
  usePurchasePremium,
  useRestorePurchases,
} from '@/features/premium/usePremium';
import { useUIStore } from '@/store/uiStore';
import { GlassCard } from '@/components/common/GlassCard';
import { Badge } from '@/components/common/Badge';
import { Button } from '@/components/common/Button';
import { Crown, Check, Sparkles, Zap, Download, Bell, Flame } from 'lucide-react';
import { cn } from '@/lib/utils';
import { PREMIUM_PRICES } from '@/config/constants';
import type { PremiumPlan } from '@/types/premium';

const BENEFIT_KEYS = [
  'unlimited',
  'exclusive',
  'noAds',
  'earlyAccess',
  'hd',
  'offline',
] as const;

const BENEFIT_ICONS = {
  unlimited: Zap,
  exclusive: Flame,
  noAds: Bell,
  earlyAccess: Sparkles,
  hd: Crown,
  offline: Download,
} as const;

export default function PremiumPage() {
  const { t } = useLanguage();
  const { isPremium } = usePremium();
  const paymentHistory = usePaymentHistory();
  const restorePurchases = useRestorePurchases();
  const purchasePremium = usePurchasePremium();
  const { openSeasonPassModal } = useUIStore();
  const [selectedPlan, setSelectedPlan] = useState<PremiumPlan>('yearly');

  const handleSubscribe = async () => {
    const response = await purchasePremium.mutateAsync(selectedPlan);
    if (response.invoice_url) {
      window.open(response.invoice_url, '_blank');
    }
  };

  return (
    <main className="min-h-screen bg-background safe-top">
      <div className="px-4 pt-4 pb-8 space-y-6">
        {/* Header */}
        <div className="text-center pt-4">
          <div className="inline-flex p-4 rounded-3xl bg-gradient-to-r from-accent via-primary to-secondary shadow-neon-strong mb-4">
            <Crown className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-display font-bold neon-text mb-2">
            {t('premium.title')}
          </h1>
          <p className="text-sm text-text-secondary">{t('premium.subtitle')}</p>
        </div>

        {/* Current status */}
        {isPremium && (
          <GlassCard className="p-4 flex items-center gap-3 border border-success/30">
            <div className="p-2 rounded-xl bg-success/15">
              <Check className="w-5 h-5 text-success" />
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-text-primary">
                Premium Active
              </h3>
              <p className="text-xs text-text-muted">
                {t('premium.benefits.unlimited')}
              </p>
            </div>
            <Badge variant="premium">Active</Badge>
          </GlassCard>
        )}

        {/* Benefits */}
        <div>
          <h2 className="text-sm font-semibold text-text-primary mb-3">
            {t('premium.benefits.unlimited')}
          </h2>
          <div className="grid grid-cols-2 gap-2">
            {BENEFIT_KEYS.map((key) => {
              const Icon = BENEFIT_ICONS[key];
              return (
                <GlassCard key={key} className="p-3 flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-primary/15 flex-shrink-0">
                    <Icon className="w-4 h-4 text-primary" />
                  </div>
                  <span className="text-xs font-medium text-text-secondary">
                    {t(`premium.benefits.${key}`)}
                  </span>
                </GlassCard>
              );
            })}
          </div>
        </div>

        {/* Plans */}
        <div>
          <h2 className="text-sm font-semibold text-text-primary mb-3">
            {t('premium.subscribe')}
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {/* Monthly */}
            <button
              onClick={() => setSelectedPlan('monthly')}
              className={cn(
                'relative p-4 rounded-2xl border-2 text-left transition-all',
                selectedPlan === 'monthly'
                  ? 'border-primary bg-primary/10 shadow-neon'
                  : 'border-border bg-surface hover:border-primary/50'
              )}
            >
              <p className="text-sm font-medium text-text-primary mb-1">
                {t('premium.monthly')}
              </p>
              <p className="text-3xl font-display font-bold text-text-primary">
                {PREMIUM_PRICES.monthly}
                <span className="text-sm text-text-muted font-normal"> ⭐</span>
              </p>
              <p className="text-xs text-text-muted mt-1">
                {PREMIUM_PRICES.monthly}{t('premium.perMonth')}
              </p>
              {selectedPlan === 'monthly' && (
                <div className="absolute top-2 right-2 p-1 rounded-full bg-primary">
                  <Check className="w-3 h-3 text-white" />
                </div>
              )}
            </button>

            {/* Yearly */}
            <button
              onClick={() => setSelectedPlan('yearly')}
              className={cn(
                'relative p-4 rounded-2xl border-2 text-left transition-all',
                selectedPlan === 'yearly'
                  ? 'border-primary bg-primary/10 shadow-neon'
                  : 'border-border bg-surface hover:border-primary/50'
              )}
            >
              <Badge variant="premium" className="absolute -top-2 right-2">
                {t('premium.save')}
              </Badge>
              <p className="text-sm font-medium text-text-primary mb-1">
                {t('premium.yearly')}
              </p>
              <p className="text-3xl font-display font-bold text-text-primary">
                {PREMIUM_PRICES.yearly}
                <span className="text-sm text-text-muted font-normal"> ⭐</span>
              </p>
              <p className="text-xs text-text-muted mt-1">
                {PREMIUM_PRICES.monthly}{t('premium.perMonth')}
              </p>
              {selectedPlan === 'yearly' && (
                <div className="absolute top-2 right-2 p-1 rounded-full bg-primary">
                  <Check className="w-3 h-3 text-white" />
                </div>
              )}
            </button>
          </div>
        </div>

        {/* Subscribe button */}
        <Button
          variant="premium"
          size="lg"
          fullWidth
          loading={purchasePremium.isLoading}
          onClick={handleSubscribe}
        >
          <Sparkles className="w-4 h-4" />
          {t('premium.subscribe')} {selectedPlan === 'yearly' ? 'Yearly' : 'Monthly'}
        </Button>

        <Button
          variant="outline"
          fullWidth
          loading={restorePurchases.isLoading}
          onClick={() => restorePurchases.mutate()}
        >
          <Check className="w-4 h-4" />
          Restore purchases
        </Button>

        {/* Season pass section */}
        <GlassCard className="p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 rounded-xl bg-accent/15">
              <Flame className="w-5 h-5 text-accent" />
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-text-primary">
                {t('anime.unlockWithSeasonPass')}
              </h3>
              <p className="text-xs text-text-muted">
                {t('player.seasonPassRequired')}
              </p>
            </div>
          </div>
          <Button
            variant="outline"
            fullWidth
            onClick={() => openSeasonPassModal()}
          >
            <Crown className="w-4 h-4" />
            {t('player.getSeasonPass')}
          </Button>
        </GlassCard>

        <GlassCard className="p-4">
          <h2 className="text-sm font-semibold text-text-primary mb-3">
            Payment history
          </h2>
          {paymentHistory.data?.length ? (
            <div className="space-y-2">
              {paymentHistory.data.slice(0, 5).map((item) => (
                <div key={item.id} className="flex items-center justify-between text-sm">
                  <span className="text-text-secondary">{item.type}</span>
                  <span className="text-text-primary">{item.amount_stars} Stars</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-text-muted">No payments yet</p>
          )}
        </GlassCard>

        {/* Terms note */}
        <p className="text-center text-xs text-text-muted px-4">
          By subscribing you agree to the Terms of Service and Privacy Policy.
          Subscription can be cancelled at any time.
        </p>
      </div>
    </main>
  );
}
