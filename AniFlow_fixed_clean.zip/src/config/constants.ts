export const APP_NAME = 'AniFlow';
export const APP_VERSION = '1.0.0';

export const FREE_EPISODES_LIMIT = 3;

export const FEED_PAGE_SIZE = 10;
export const EXPLORE_PAGE_SIZE = 20;

export const PREMIUM_PRICES = {
  monthly: 50, // Telegram Stars
  yearly: 360, // Telegram Stars (40% off)
  seasonPass: 100, // Telegram Stars
} as const;

export const REFERRAL_REWARD = {
  perReferral: 5, // Stars per referral
  threshold: 3, // Referrals needed for reward
  bonus: 20, // Bonus Stars at threshold
} as const;

export const STORAGE_KEYS = {
  language: 'aniflow_language',
  theme: 'aniflow_theme',
  authToken: 'aniflow_auth_token',
  favorites: 'aniflow_favorites',
  history: 'aniflow_history',
  continueWatching: 'aniflow_continue_watching',
  playerSettings: 'aniflow_player_settings',
} as const;

export const SUPPORTED_GENRES = [
  'Action',
  'Adventure',
  'Comedy',
  'Drama',
  'Fantasy',
  'Horror',
  'Mecha',
  'Mystery',
  'Romance',
  'Sci-Fi',
  'Slice of Life',
  'Sports',
  'Supernatural',
  'Thriller',
] as const;
