export const TELEGRAM_CONFIG = {
  botUsername: process.env.NEXT_PUBLIC_BOT_USERNAME ?? 'AniFlowBot',
  referralUrl: process.env.NEXT_PUBLIC_REFERRAL_BOT_URL ?? 'https://t.me/AniFlowBot/start?ref=',
  colors: {
    header: '#0a0a0f',
    background: '#0a0a0f',
    button: '#a855f7',
    buttonText: '#ffffff',
  },
} as const;
