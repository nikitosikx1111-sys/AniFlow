export type ThemeMode = 'dark' | 'light' | 'system';

export interface ThemeColors {
  background: string;
  surface: string;
  surface2: string;
  border: string;
  primary: string;
  primaryLight: string;
  primaryDark: string;
  secondary: string;
  secondaryLight: string;
  accent: string;
  accentLight: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  success: string;
  warning: string;
  error: string;
}

export const darkTheme: ThemeColors = {
  background: '#0a0a0f',
  surface: '#12121a',
  surface2: '#1a1a26',
  border: '#2a2a3a',
  primary: '#a855f7',
  primaryLight: '#c084fc',
  primaryDark: '#7c3aed',
  secondary: '#06b6d4',
  secondaryLight: '#22d3ee',
  accent: '#f472b6',
  accentLight: '#f9a8d4',
  textPrimary: '#f3f4f6',
  textSecondary: '#9ca3af',
  textMuted: '#6b7280',
  success: '#22c55e',
  warning: '#f59e0b',
  error: '#ef4444',
};

export const lightTheme: ThemeColors = {
  background: '#f3f4f6',
  surface: '#ffffff',
  surface2: '#f9fafb',
  border: '#e5e7eb',
  primary: '#7c3aed',
  primaryLight: '#a855f7',
  primaryDark: '#6d28d9',
  secondary: '#0891b2',
  secondaryLight: '#06b6d4',
  accent: '#db2777',
  accentLight: '#f472b6',
  textPrimary: '#111827',
  textSecondary: '#4b5563',
  textMuted: '#9ca3af',
  success: '#16a34a',
  warning: '#d97706',
  error: '#dc2626',
};

export const themes: Record<Exclude<ThemeMode, 'system'>, ThemeColors> = {
  dark: darkTheme,
  light: lightTheme,
};

export function getSystemTheme(): Exclude<ThemeMode, 'system'> {
  if (typeof window === 'undefined') return 'dark';
  return window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
}

export function resolveTheme(mode: ThemeMode): ThemeColors {
  if (mode === 'system') {
    return themes[getSystemTheme()];
  }
  return themes[mode];
}
