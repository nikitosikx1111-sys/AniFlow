from datetime import datetime
from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, JSON, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    username: Mapped[str | None] = mapped_column(String, nullable=True)
    first_name: Mapped[str] = mapped_column(String)
    avatar_url: Mapped[str | None] = mapped_column(String, nullable=True)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    is_premium: Mapped[bool] = mapped_column(Boolean, default=False)
    premium_expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    referral_code: Mapped[str] = mapped_column(String, unique=True)
    referral_count: Mapped[int] = mapped_column(Integer, default=0)
    is_banned: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class Anime(Base):
    __tablename__ = "anime"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    title: Mapped[dict] = mapped_column(JSON)
    description: Mapped[dict] = mapped_column(JSON)
    cover_url: Mapped[str] = mapped_column(String)
    banner_url: Mapped[str] = mapped_column(String)
    studio: Mapped[str] = mapped_column(String, default="")
    genres: Mapped[list] = mapped_column(JSON, default=list)
    status: Mapped[str] = mapped_column(String, default="ongoing")
    rating: Mapped[float] = mapped_column(Float, default=0)
    views: Mapped[int] = mapped_column(Integer, default=0)
    likes: Mapped[int] = mapped_column(Integer, default=0)
    is_premium: Mapped[bool] = mapped_column(Boolean, default=False)
    is_hidden: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    seasons: Mapped[list["Season"]] = relationship(back_populates="anime")


class Season(Base):
    __tablename__ = "seasons"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    anime_id: Mapped[str] = mapped_column(ForeignKey("anime.id"))
    number: Mapped[int] = mapped_column(Integer)
    title: Mapped[dict] = mapped_column(JSON)
    anime: Mapped[Anime] = relationship(back_populates="seasons")
    episodes: Mapped[list["Episode"]] = relationship(back_populates="season")


class Episode(Base):
    __tablename__ = "episodes"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    season_id: Mapped[str] = mapped_column(ForeignKey("seasons.id"))
    anime_id: Mapped[str] = mapped_column(ForeignKey("anime.id"))
    number: Mapped[int] = mapped_column(Integer)
    title: Mapped[dict] = mapped_column(JSON)
    video_url: Mapped[str] = mapped_column(Text)
    video_sources: Mapped[list] = mapped_column(JSON, default=list)
    thumbnail_url: Mapped[str] = mapped_column(String)
    duration: Mapped[int] = mapped_column(Integer, default=0)
    is_free: Mapped[bool] = mapped_column(Boolean, default=True)
    views: Mapped[int] = mapped_column(Integer, default=0)
    likes: Mapped[int] = mapped_column(Integer, default=0)
    scheduled_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    season: Mapped[Season] = relationship(back_populates="episodes")


class WatchProgress(Base):
    __tablename__ = "watch_progress"

    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), primary_key=True)
    episode_id: Mapped[str] = mapped_column(ForeignKey("episodes.id"), primary_key=True)
    progress: Mapped[float] = mapped_column(Float, default=0)
    last_watched_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class Payment(Base):
    __tablename__ = "payments"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    type: Mapped[str] = mapped_column(String)
    status: Mapped[str] = mapped_column(String, default="pending")
    amount_stars: Mapped[int] = mapped_column(Integer)
    telegram_payment_id: Mapped[str | None] = mapped_column(String, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
