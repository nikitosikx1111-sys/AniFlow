from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routers import admin, anime, auth, player, premium, referral

app = FastAPI(title="AniFlow API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "https://web.telegram.org"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
app.include_router(anime.router, prefix="/api/anime", tags=["anime"])
app.include_router(player.router, prefix="/api/episodes", tags=["player"])
app.include_router(premium.router, prefix="/api/premium", tags=["premium"])
app.include_router(referral.router, prefix="/api/referral", tags=["referral"])
app.include_router(admin.router, prefix="/api/admin", tags=["admin"])


@app.get("/health")
async def health():
    return {"ok": True}
