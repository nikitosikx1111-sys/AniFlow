from datetime import datetime, timedelta, timezone
from hashlib import sha256
import hmac
from urllib.parse import parse_qsl

from jose import jwt

from app.core.config import settings


def create_access_token(subject: str) -> str:
    expires_at = datetime.now(timezone.utc) + timedelta(days=30)
    return jwt.encode(
        {"sub": subject, "exp": expires_at},
        settings.jwt_secret,
        algorithm=settings.jwt_algorithm,
    )


def verify_telegram_init_data(init_data: str) -> dict[str, str]:
    pairs = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = pairs.pop("hash", "")
    data_check = "\n".join(f"{key}={value}" for key, value in sorted(pairs.items()))
    secret = hmac.new(b"WebAppData", settings.telegram_bot_token.encode(), sha256).digest()
    expected_hash = hmac.new(secret, data_check.encode(), sha256).hexdigest()
    if not settings.telegram_bot_token or not hmac.compare_digest(expected_hash, received_hash):
        raise ValueError("Invalid Telegram initData")
    return pairs
