from fastapi import APIRouter

router = APIRouter()


@router.get("")
async def info():
    return {
        "code": "AF-DEMO",
        "referral_link": "https://t.me/aniflow_bot/app?startapp=AF-DEMO",
        "referral_count": 0,
        "reward_progress": 0,
        "total_earned": 0,
        "next_reward_at": 3,
    }


@router.get("/history")
async def history():
    return []


@router.post("/redeem")
async def redeem():
    return {"id": "demo", "reward": 0, "status": "pending", "created_at": "2026-08-07T00:00:00Z"}
