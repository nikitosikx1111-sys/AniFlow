from fastapi import APIRouter

router = APIRouter()


@router.get("")
async def list_anime(page: int = 1, limit: int = 20):
    return {"items": [], "page": page, "limit": limit, "total": 0, "hasMore": False}


@router.get("/trending")
async def trending():
    return []


@router.get("/recommended")
async def recommended():
    return []


@router.get("/recent")
async def recent():
    return []


@router.get("/continue-watching")
async def continue_watching():
    return []


@router.get("/{anime_id}")
async def detail(anime_id: str):
    return {"id": anime_id, "seasons": [], "episodes": [], "recommendations": []}


@router.get("/{anime_id}/episodes")
async def episodes(anime_id: str):
    return []


@router.post("/{anime_id}/like")
async def like(anime_id: str):
    return {"ok": True}


@router.post("/{anime_id}/favorite")
async def favorite(anime_id: str):
    return {"ok": True}
