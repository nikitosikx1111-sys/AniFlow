from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()


class ProgressPayload(BaseModel):
    progress: float


@router.get("/{episode_id}")
async def episode(episode_id: str):
    raise HTTPException(status_code=404, detail=f"Episode {episode_id} not found")


@router.post("/{episode_id}/progress")
async def save_progress(episode_id: str, payload: ProgressPayload):
    return {"episode_id": episode_id, "progress": payload.progress}


@router.get("/{episode_id}/next")
async def next_episode(episode_id: str):
    return None


@router.post("/{episode_id}/like")
async def like_episode(episode_id: str):
    return {"ok": True}
