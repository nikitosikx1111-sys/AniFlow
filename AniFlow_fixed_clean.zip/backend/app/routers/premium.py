import uuid

from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()


class CheckoutPayload(BaseModel):
    plan: str


@router.get("/status")
async def status():
    return {"is_premium": False, "season_passes": []}


@router.post("/checkout")
async def checkout(payload: CheckoutPayload):
    invoice_id = str(uuid.uuid4())
    return {"invoice_id": invoice_id, "invoice_url": f"https://t.me/$invoice/{invoice_id}"}


@router.post("/confirm")
async def confirm():
    return {"is_premium": True, "season_passes": []}


@router.get("/payments")
async def payments():
    return []


@router.post("/restore")
async def restore():
    return {"is_premium": False, "season_passes": []}


@router.post("/season-pass/{anime_id}")
async def season_pass(anime_id: str):
    invoice_id = str(uuid.uuid4())
    return {"invoice_id": invoice_id, "invoice_url": f"https://t.me/$invoice/{invoice_id}"}
