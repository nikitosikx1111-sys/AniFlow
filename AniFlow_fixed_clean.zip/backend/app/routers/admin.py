import uuid

from fastapi import APIRouter, File, UploadFile
from pydantic import BaseModel

router = APIRouter()


class HiddenPayload(BaseModel):
    hidden: bool


class SchedulePayload(BaseModel):
    scheduled_at: str


@router.get("/stats")
async def stats():
    return {
        "totalUsers": 0,
        "totalAnime": 0,
        "totalViews": 0,
        "totalLikes": 0,
        "premiumUsers": 0,
        "activeSubscriptions": 0,
        "revenue": 0,
        "dailyViews": [],
    }


@router.post("/anime")
async def create_anime(payload: dict):
    return {"id": str(uuid.uuid4()), **payload}


@router.put("/anime/{anime_id}")
async def update_anime(anime_id: str, payload: dict):
    return {"id": anime_id, **payload}


@router.delete("/anime/{anime_id}", status_code=204)
async def delete_anime(anime_id: str):
    return None


@router.patch("/anime/{anime_id}/hide")
async def hide_anime(anime_id: str, payload: HiddenPayload):
    return {"id": anime_id, "is_hidden": payload.hidden}


@router.post("/anime/{anime_id}/seasons")
async def create_season(anime_id: str, payload: dict):
    return {"id": str(uuid.uuid4()), "anime_id": anime_id, **payload}


@router.post("/anime/{anime_id}/episodes")
async def create_episode(anime_id: str, payload: dict):
    return {"id": str(uuid.uuid4()), "anime_id": anime_id, **payload}


@router.post("/anime/{anime_id}/cover")
async def upload_cover(anime_id: str, file: UploadFile = File(...)):
    return {"cover_url": f"/uploads/{anime_id}/{file.filename}"}


@router.post("/episodes/{episode_id}/video")
async def upload_video(episode_id: str, file: UploadFile = File(...)):
    return {"video_url": f"/uploads/{episode_id}/{file.filename}"}


@router.patch("/episodes/{episode_id}/schedule")
async def schedule_episode(episode_id: str, payload: SchedulePayload):
    return {"id": episode_id, "scheduled_at": payload.scheduled_at}


@router.post("/users/{user_id}/grant-premium")
async def grant_premium(user_id: str):
    return {"user_id": user_id, "is_premium": True}


@router.post("/users/{user_id}/ban")
async def ban_user(user_id: str):
    return {"user_id": user_id, "is_banned": True}
