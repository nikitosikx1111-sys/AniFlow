import json
import uuid

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.core.security import create_access_token, verify_telegram_init_data

router = APIRouter()


class TelegramAuthRequest(BaseModel):
    initData: str


@router.post("/telegram")
async def telegram_auth(payload: TelegramAuthRequest):
    try:
        data = verify_telegram_init_data(payload.initData)
    except ValueError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc

    telegram_user = json.loads(data.get("user", "{}"))
    user_id = str(telegram_user.get("id") or uuid.uuid4())
    user = {
        "id": user_id,
        "telegram_id": telegram_user.get("id"),
        "username": telegram_user.get("username") or "",
        "first_name": telegram_user.get("first_name") or "AniFlow",
        "avatar_url": telegram_user.get("photo_url"),
        "language": "uk",
        "is_premium": bool(telegram_user.get("is_premium")),
        "is_admin": False,
        "referral_code": f"AF{user_id[-6:]}",
        "referral_count": 0,
        "created_at": "2026-08-07T00:00:00Z",
        "updated_at": "2026-08-07T00:00:00Z",
    }
    return {"token": create_access_token(user["id"]), "user": user}


@router.get("/me")
async def me():
    raise HTTPException(status_code=501, detail="JWT user lookup must be connected to PostgreSQL")


@router.post("/refresh")
async def refresh():
    raise HTTPException(status_code=501, detail="Refresh token flow is not enabled")
